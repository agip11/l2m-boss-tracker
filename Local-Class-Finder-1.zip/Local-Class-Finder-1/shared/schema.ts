import { sql } from "drizzle-orm";
import { pgTable, text, integer, boolean, bigint } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: text("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const discordConfig = pgTable("discord_config", {
  id: text("id").primaryKey().default(sql`gen_random_uuid()`),
  guildId: text("guild_id").notNull().unique(),
  webhookUrl: text("webhook_url"),
  spawnAlerts15min: boolean("spawn_alerts_15min").default(true),
  spawnAlertsNow: boolean("spawn_alerts_now").default(true),
  killLogs: boolean("kill_logs").default(true),
  dailySummary: boolean("daily_summary").default(false),
});

export const bossState = pgTable("boss_state", {
  id: text("id").primaryKey().default(sql`gen_random_uuid()`),
  bossId: text("boss_id").notNull().unique(),
  lastKilledTime: bigint("last_killed_time", { mode: "number" }),
  autoSpawnedAt: bigint("auto_spawned_at", { mode: "number" }),
});

export const clans = pgTable("clans", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  leader: text("leader").notNull(),
  createdDate: text("created_date").notNull(),
});

export const clanMembers = pgTable("clan_members", {
  id: text("id").primaryKey(),
  clanId: text("clan_id").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  joinDate: text("join_date").notNull(),
});

export const killRecords = pgTable("kill_records", {
  id: text("id").primaryKey(),
  clanId: text("clan_id").notNull(),
  bossName: text("boss_name").notNull(),
  region: text("region").notNull(),
  killTime: bigint("kill_time", { mode: "number" }).notNull(),
  participants: text("participants").notNull(),
  reportedBy: text("reported_by").notNull(),
  weekNumber: integer("week_number"),
  year: integer("year"),
});

export const bossAttendance = pgTable("boss_attendance", {
  id: text("id").primaryKey().default(sql`gen_random_uuid()`),
  killRecordId: text("kill_record_id").notNull(),
  clanId: text("clan_id").notNull(),
  memberName: text("member_name").notNull(),
  weekNumber: integer("week_number").notNull(),
  year: integer("year").notNull(),
  bossName: text("boss_name").notNull(),
  attendedAt: bigint("attended_at", { mode: "number" }).notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertDiscordConfigSchema = createInsertSchema(discordConfig).omit({
  id: true,
});

export const insertBossStateSchema = createInsertSchema(bossState).omit({
  id: true,
});

export const insertClanSchema = createInsertSchema(clans);
export const insertClanMemberSchema = createInsertSchema(clanMembers);
export const insertKillRecordSchema = createInsertSchema(killRecords);
export const insertBossAttendanceSchema = createInsertSchema(bossAttendance).omit({ id: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertDiscordConfig = z.infer<typeof insertDiscordConfigSchema>;
export type DiscordConfig = typeof discordConfig.$inferSelect;
export type InsertBossState = z.infer<typeof insertBossStateSchema>;
export type BossStateRow = typeof bossState.$inferSelect;
export type InsertClan = z.infer<typeof insertClanSchema>;
export type Clan = typeof clans.$inferSelect;
export type InsertClanMember = z.infer<typeof insertClanMemberSchema>;
export type ClanMember = typeof clanMembers.$inferSelect;
export type InsertKillRecord = z.infer<typeof insertKillRecordSchema>;
export type KillRecord = typeof killRecords.$inferSelect;
export type InsertBossAttendance = z.infer<typeof insertBossAttendanceSchema>;
export type BossAttendance = typeof bossAttendance.$inferSelect;
