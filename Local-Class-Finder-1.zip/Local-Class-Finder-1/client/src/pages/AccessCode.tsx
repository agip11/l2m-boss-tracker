import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Lock, AlertCircle } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

const ACCESS_CODE_KEY = "tracker_access_code";
const DEFAULT_ACCESS_CODE = "1234";

const getAccessCode = (): string => {
  return localStorage.getItem(ACCESS_CODE_KEY) || DEFAULT_ACCESS_CODE;
};

interface AccessCodeProps {
  onAccessGranted?: () => void;
}

export function AccessCode({ onAccessGranted }: AccessCodeProps) {
  const [, setLocation] = useLocation();
  const [code, setCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    if (!code.trim()) {
      setError("Masukkan kode akses");
      return;
    }

    setIsLoading(true);
    
    setTimeout(() => {
      if (code === getAccessCode()) {
        // Simpan status akses ke localStorage
        localStorage.setItem("tracker_access", "true");
        setIsLoading(false);
        onAccessGranted?.();
        setLocation("/");
      } else {
        setError("Kode akses salah!");
        setCode("");
        setIsLoading(false);
      }
    }, 800);
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-gradient-to-br from-background via-background to-primary/5">
      <div className="w-full max-w-md space-y-6">
        <Card className="border-primary/20 bg-card/50 backdrop-blur-sm shadow-2xl shadow-black/50">
          <CardHeader className="text-center space-y-4 pb-6">
            <div className="mx-auto w-16 h-16 rounded-full bg-primary/10 border border-primary/50 flex items-center justify-center text-primary shadow-[0_0_30px_rgba(234,179,8,0.2)]">
              <Lock className="w-8 h-8" />
            </div>
            <div>
              <CardTitle className="font-display text-3xl font-bold tracking-wide uppercase">Access Code</CardTitle>
              <CardDescription>Masukkan kode untuk akses tracker</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label className="uppercase text-xs font-bold tracking-widest text-muted-foreground">
                  Kode Akses
                </Label>
                <Input 
                  type="password"
                  placeholder="••••"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="bg-background/50 border-primary/20 focus:border-primary text-center text-lg tracking-widest font-bold"
                  maxLength={10}
                  autoFocus
                />
              </div>

              {error && (
                <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-500 text-sm">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {error}
                </div>
              )}

              <Button 
                className="w-full font-bold uppercase tracking-widest bg-primary hover:bg-primary/90" 
                size="lg"
                disabled={isLoading || !code}
              >
                {isLoading ? "Verifying..." : "Akses Tracker"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
