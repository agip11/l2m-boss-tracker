import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Progress } from "@/components/ui/progress";
import { ClanMember } from "@/lib/clans";
import { Users, Swords, LogOut, Plus, Trash2, Download, TrendingUp, Edit2, Loader2, Calendar, ChevronLeft, ChevronRight, Trophy } from "lucide-react";
import { useLocation } from "wouter";
import { format } from "date-fns";
import { AddMemberModal } from "@/components/AddMemberModal";
import { EditClanNameModal } from "@/components/EditClanNameModal";
import { EditKillModal } from "@/components/EditKillModal";
import { ClanSelector } from "@/components/ClanSelector";
import { exportToCSV, exportToJSON, downloadFile } from "@/lib/export";
import { getCurrentUser, logout } from "@/lib/auth";
import { useClanData, KillRecord } from "@/hooks/use-clan-data";
import { useAttendance } from "@/hooks/use-attendance";

export function ClanDashboard() {
  const [, setLocation] = useLocation();
  const user = getCurrentUser();
  
  if (!user) {
    setLocation("/login");
    return null;
  }

  const { 
    clans, 
    loading, 
    getClanById, 
    getClanMembers, 
    getClanKillRecords, 
    getClanDisplayName,
    addClanMember: apiAddMember,
    deleteClanMember: apiDeleteMember,
    updateClanName: apiUpdateClanName,
    updateKillRecord: apiUpdateKillRecord
  } = useClanData();

  const [selectedClanId, setSelectedClanId] = useState(user.clanId);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditNameModalOpen, setIsEditNameModalOpen] = useState(false);
  const [editingKill, setEditingKill] = useState<KillRecord | null>(null);
  const [isEditKillModalOpen, setIsEditKillModalOpen] = useState(false);

  const {
    weeklyAttendance,
    loading: attendanceLoading,
    currentWeek,
    currentYear,
    goToPreviousWeek,
    goToNextWeek,
    goToCurrentWeek,
  } = useAttendance(selectedClanId);

  const selectedClan = getClanById(selectedClanId);
  const clanDisplayName = getClanDisplayName(selectedClanId);
  const clanMembers = getClanMembers(selectedClanId);
  const mockKillRecords = getClanKillRecords(selectedClanId);

  const handleClanChange = (clanId: string) => {
    setSelectedClanId(clanId);
  };

  const handleUpdateClanName = async (newName: string) => {
    await apiUpdateClanName(selectedClanId, newName);
  };

  const handleEditKill = (kill: KillRecord) => {
    setEditingKill(kill);
    setIsEditKillModalOpen(true);
  };

  const handleSaveKillParticipants = async (participantIds: string[]) => {
    if (!editingKill) return;
    
    // Get member names for attendance tracking
    const memberNames = participantIds
      .map(id => clanMembers.find(m => m.id === id)?.name)
      .filter((name): name is string => !!name);
    
    // Get reporter name
    const reporterMember = clanMembers.find(m => m.id === editingKill.reportedBy);
    
    await apiUpdateKillRecord(
      selectedClanId, 
      editingKill.id, 
      participantIds,
      memberNames,
      editingKill.bossName,
      editingKill.killTime.getTime(),
      reporterMember?.name
    );
    setEditingKill(null);
    setIsEditKillModalOpen(false);
  };

  const handleLogout = () => {
    logout();
    setLocation("/login");
  };

  const handleAddMember = async (name: string, role: "Leader" | "Officer" | "Member") => {
    const newMember: ClanMember = {
      id: `m${Date.now()}`,
      name,
      role,
      joinDate: format(new Date(), "yyyy-MM-dd")
    };
    await apiAddMember(selectedClanId, newMember);
  };

  const handleDeleteMember = async (memberId: string) => {
    if (clanMembers.length === 1) {
      alert("Tidak bisa hapus member terakhir!");
      return;
    }
    await apiDeleteMember(selectedClanId, memberId);
  };

  const handleDownloadCSV = () => {
    const csv = exportToCSV(clanMembers, mockKillRecords);
    downloadFile(csv, `${clanDisplayName}_${format(new Date(), 'yyyy-MM-dd_HHmmss')}.csv`, "text/csv");
  };

  const handleDownloadJSON = () => {
    const json = exportToJSON(clanMembers, mockKillRecords);
    downloadFile(json, `${clanDisplayName}_${format(new Date(), 'yyyy-MM-dd_HHmmss')}.json`, "application/json");
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-zinc-950">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-purple-500" />
          <p className="text-zinc-400">Loading clan data...</p>
        </div>
      </div>
    );
  }

  // Calculate statistics
  const memberStats = clanMembers.map(member => {
    const participationCount = mockKillRecords.filter(k => k.participants.includes(member.id)).length;
    const reportCount = mockKillRecords.filter(k => k.reportedBy === member.id).length;
    return {
      ...member,
      participationCount,
      reportCount,
      totalActivity: participationCount + reportCount
    };
  }).sort((a, b) => b.totalActivity - a.totalActivity);

  const totalKills = mockKillRecords.length;

  // Role-based permissions
  const canManageMembers = user.role === "Admin" || user.role === "Leader";
  const canDownload = user.role === "Admin" || user.role === "Leader";
  const canSwitchClan = user.role === "Admin";

  const roleColors: Record<string, string> = {
    Admin: "bg-red-500/20 text-red-500",
    Leader: "bg-orange-500/20 text-orange-500",
    Officer: "bg-blue-500/20 text-blue-500"
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header */}
      <div className="flex justify-between items-start mb-8">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h1 className="font-display text-4xl font-bold uppercase tracking-tight">CLAN COMMAND CENTER</h1>
            <Badge className={roleColors[user.role]}>
              {user.role === "Leader" ? "KETUA" : user.role}
            </Badge>
          </div>
          <p className="text-muted-foreground">Logged in as <span className="text-primary font-bold">{user.username}</span> | Clan: <span className="text-accent font-bold">{clanDisplayName}</span> {canManageMembers && <button onClick={() => setIsEditNameModalOpen(true)} className="ml-2 inline text-primary hover:text-primary/80 transition-colors" title="Edit clan name"><Edit2 className="w-4 h-4 inline" /></button>}</p>
        </div>
        <div className="flex items-center gap-2">
          {canSwitchClan && (
            <ClanSelector selectedClanId={selectedClanId} onSelectClan={handleClanChange} clans={clans} />
          )}
          
          {canDownload && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="text-primary border-primary/50 hover:bg-primary/10 gap-2">
                  <Download className="w-4 h-4" />
                  Download
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-card border-border">
                <DropdownMenuItem 
                  onClick={handleDownloadCSV}
                  className="cursor-pointer flex items-center gap-2"
                >
                  📄 Download CSV
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={handleDownloadJSON}
                  className="cursor-pointer flex items-center gap-2"
                >
                  📋 Download JSON
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
          
          <Button variant="outline" className="text-red-500 border-red-500/50 hover:bg-red-500/10" onClick={handleLogout}>
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>

      <Tabs defaultValue="weekly" className="w-full">
        <TabsList className="grid w-full gap-0" style={{ gridTemplateColumns: `repeat(${canManageMembers ? 4 : 3}, minmax(0, 1fr))` }}>
          <TabsTrigger value="weekly" className="uppercase text-xs font-bold flex items-center gap-2">
            <Calendar className="w-4 h-4" /> Weekly Recap
          </TabsTrigger>
          <TabsTrigger value="stats" className="uppercase text-xs font-bold flex items-center gap-2">
            <TrendingUp className="w-4 h-4" /> Statistics
          </TabsTrigger>
          {canManageMembers && (
            <TabsTrigger value="members" className="uppercase text-xs font-bold flex items-center gap-2">
              <Users className="w-4 h-4" /> Members ({clanMembers.length})
            </TabsTrigger>
          )}
          <TabsTrigger value="kills" className="uppercase text-xs font-bold flex items-center gap-2">
            <Swords className="w-4 h-4" /> Kill History ({totalKills})
          </TabsTrigger>
        </TabsList>

        {/* Weekly Recap Tab */}
        <TabsContent value="weekly">
          <div className="space-y-6">
            <Card className="border-primary/30 bg-gradient-to-br from-primary/5 to-transparent">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Button 
                      variant="outline" 
                      size="icon"
                      onClick={goToPreviousWeek}
                      className="border-primary/30 hover:bg-primary/10"
                      data-testid="button-prev-week"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    <div className="text-center">
                      <CardTitle className="text-xl uppercase tracking-wide">
                        Week {currentWeek} - {currentYear}
                      </CardTitle>
                      <CardDescription className="text-sm">
                        Boss Attendance Points
                      </CardDescription>
                    </div>
                    <Button 
                      variant="outline" 
                      size="icon"
                      onClick={goToNextWeek}
                      className="border-primary/30 hover:bg-primary/10"
                      data-testid="button-next-week"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                  <Button 
                    variant="ghost" 
                    onClick={goToCurrentWeek}
                    className="text-primary hover:bg-primary/10 text-xs uppercase"
                    data-testid="button-current-week"
                  >
                    Minggu Ini
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div className="p-4 rounded-lg bg-primary/10">
                    <p className="text-3xl font-bold text-primary">{weeklyAttendance?.totalKills || 0}</p>
                    <p className="text-xs text-muted-foreground uppercase tracking-widest">Total Boss Kills</p>
                  </div>
                  <div className="p-4 rounded-lg bg-accent/10">
                    <p className="text-3xl font-bold text-accent">{weeklyAttendance?.recap.length || 0}</p>
                    <p className="text-xs text-muted-foreground uppercase tracking-widest">Active Members</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {attendanceLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : weeklyAttendance?.recap && weeklyAttendance.recap.length > 0 ? (
              <div className="space-y-3">
                {weeklyAttendance.recap.map((member, idx) => (
                  <Card 
                    key={member.memberName} 
                    className={`border-border/50 hover:border-primary/30 transition-all ${idx < 3 ? 'bg-gradient-to-r from-primary/5 to-transparent' : ''}`}
                    data-testid={`attendance-member-${idx}`}
                  >
                    <CardContent className="pt-4 pb-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`flex items-center justify-center w-10 h-10 rounded-full font-bold text-sm ${
                            idx === 0 ? 'bg-yellow-500/20 text-yellow-500' :
                            idx === 1 ? 'bg-gray-400/20 text-gray-400' :
                            idx === 2 ? 'bg-orange-600/20 text-orange-600' :
                            'bg-primary/20 text-primary'
                          }`}>
                            {idx < 3 ? <Trophy className="w-5 h-5" /> : `#${idx + 1}`}
                          </div>
                          <div>
                            <h3 className="font-display text-lg font-bold uppercase tracking-wide" data-testid={`text-member-name-${idx}`}>
                              {member.memberName}
                            </h3>
                            <p className="text-xs text-muted-foreground">
                              {member.bosses.slice(0, 3).join(", ")}
                              {member.bosses.length > 3 ? ` +${member.bosses.length - 3} more` : ""}
                            </p>
                          </div>
                        </div>
                        <Badge 
                          className={`text-lg px-4 py-2 font-bold ${
                            idx === 0 ? 'bg-yellow-500/20 text-yellow-500' :
                            idx === 1 ? 'bg-gray-400/20 text-gray-400' :
                            idx === 2 ? 'bg-orange-600/20 text-orange-600' :
                            'bg-primary/20 text-primary'
                          }`}
                          data-testid={`text-member-points-${idx}`}
                        >
                          {member.points} pts
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="border-dashed border-border/50">
                <CardContent className="pt-12 pb-12 text-center">
                  <Calendar className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
                  <p className="text-muted-foreground">Belum ada data attendance untuk minggu ini</p>
                  <p className="text-xs text-muted-foreground mt-2">Data akan muncul setelah boss kill dilaporkan</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* Statistics Tab */}
        <TabsContent value="stats">
          <div className="space-y-4">
            {memberStats.map((member, idx) => (
              <Card key={member.id} className="border-border/50 hover:border-primary/30 transition-all">
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/20 text-primary font-bold text-sm">
                          #{idx + 1}
                        </div>
                        <div>
                          <h3 className="font-display text-lg font-bold uppercase tracking-wide">{member.name}</h3>
                          <p className="text-xs text-muted-foreground">{member.role}</p>
                        </div>
                      </div>
                      <Badge className="bg-primary/20 text-primary text-base px-3 py-1 font-bold">
                        {member.totalActivity} Activity
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 gap-4 py-3 border-y border-border">
                      <div className="space-y-1">
                        <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Participations</p>
                        <p className="text-2xl font-bold text-primary">{member.participationCount}</p>
                        <p className="text-xs text-muted-foreground">dari {totalKills} total kills</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Kill Reports</p>
                        <p className="text-2xl font-bold text-accent">{member.reportCount}</p>
                        <p className="text-xs text-muted-foreground">timings reported</p>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-medium text-muted-foreground uppercase tracking-widest">Participation Rate</span>
                        <span className="text-sm font-bold text-primary">
                          {totalKills > 0 ? Math.round((member.participationCount / totalKills) * 100) : 0}%
                        </span>
                      </div>
                      <Progress 
                        value={totalKills > 0 ? (member.participationCount / totalKills) * 100 : 0}
                        className="h-2"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Members Tab */}
        {canManageMembers && (
          <TabsContent value="members">
            <div className="mb-6">
              <Button 
                onClick={() => setIsAddModalOpen(true)}
                className="bg-primary hover:bg-primary/90 text-primary-foreground uppercase font-bold tracking-wider gap-2"
              >
                <Plus className="w-4 h-4" />
                Tambah Member
              </Button>
            </div>

            <div className="grid gap-4">
              {clanMembers.length > 0 ? (
                clanMembers.map(member => (
                  <Card key={member.id} className="border-border/50 hover:border-primary/30 transition-all">
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-display text-lg font-bold uppercase tracking-wide">{member.name}</h3>
                          <p className="text-sm text-muted-foreground">Joined: {member.joinDate}</p>
                        </div>
                        <div className="flex items-center gap-3">
                          <Badge className={
                            member.role === "Leader" ? "bg-red-500/20 text-red-500" :
                            member.role === "Officer" ? "bg-orange-500/20 text-orange-500" :
                            "bg-blue-500/20 text-blue-500"
                          }>
                            {member.role}
                          </Badge>
                          {clanMembers.length > 1 && (
                            <Button 
                              size="icon"
                              variant="ghost"
                              className="text-red-500 hover:bg-red-500/10"
                              onClick={() => handleDeleteMember(member.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card className="border-dashed border-border/50">
                  <CardContent className="pt-12 text-center">
                    <p className="text-muted-foreground">Belum ada member clan</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        )}

        {/* Kill History Tab */}
        <TabsContent value="kills">
          <div className="space-y-4">
            {mockKillRecords.length > 0 ? (
              mockKillRecords.map(kill => {
                const reportedByMember = clanMembers.find(m => m.id === kill.reportedBy);
                const participantMembers = clanMembers.filter(m => kill.participants.includes(m.id));
                
                return (
                  <Card key={kill.id} className="border-primary/20 bg-primary/5">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg uppercase tracking-wide">{kill.bossName}</CardTitle>
                          <CardDescription className="text-sm mt-1">
                            <span className="text-primary font-mono">{kill.region}</span> • {format(kill.killTime, "dd/MM/yyyy HH:mm")}
                          </CardDescription>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className="bg-green-500/20 text-green-500">KILLED</Badge>
                          {canManageMembers && (
                            <Button 
                              size="icon"
                              variant="ghost"
                              className="text-primary hover:bg-primary/10"
                              onClick={() => handleEditKill(kill)}
                              title="Edit participants"
                            >
                              <Edit2 className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-2">Reported By</p>
                        <p className="text-sm font-medium text-foreground">{reportedByMember?.name || "Unknown"}</p>
                      </div>
                      
                      {participantMembers.length > 0 && (
                        <div>
                          <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-2">Participants ({participantMembers.length})</p>
                          <div className="flex flex-wrap gap-2">
                            {participantMembers.map(member => (
                              <Badge 
                                key={member.id}
                                variant="outline"
                                className="border-primary/30 text-foreground"
                              >
                                {member.name}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })
            ) : (
              <Card className="border-dashed border-border/50">
                <CardContent className="pt-12 text-center">
                  <p className="text-muted-foreground">Belum ada kill record untuk clan ini</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>

      <AddMemberModal 
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAddMember={handleAddMember}
      />

      <EditClanNameModal
        isOpen={isEditNameModalOpen}
        currentName={clanDisplayName}
        onClose={() => setIsEditNameModalOpen(false)}
        onSave={handleUpdateClanName}
      />

      {editingKill && (
        <EditKillModal
          isOpen={isEditKillModalOpen}
          onClose={() => {
            setIsEditKillModalOpen(false);
            setEditingKill(null);
          }}
          onSave={handleSaveKillParticipants}
          bossName={editingKill.bossName}
          region={editingKill.region}
          killTime={editingKill.killTime}
          currentParticipants={editingKill.participants}
          availableMembers={clanMembers}
        />
      )}
    </div>
  );
}
