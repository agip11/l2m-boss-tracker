import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Settings, AlertCircle, Check } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { getCurrentUser } from "@/lib/auth";

const ACCESS_CODE_KEY = "tracker_access_code";

export function AdminSettings() {
  const [, setLocation] = useLocation();
  const user = getCurrentUser();
  const [newCode, setNewCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  // Only Admin can access
  if (!user || user.role !== "Admin") {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="border-red-500/30 bg-red-500/5">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3 text-red-600">
              <AlertCircle className="w-5 h-5" />
              <span className="font-medium">Hanya Admin yang bisa akses halaman ini</span>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleChangeCode = () => {
    setError("");
    
    if (!newCode.trim()) {
      setError("Masukkan kode akses baru");
      return;
    }

    if (newCode.length < 4) {
      setError("Kode akses minimal 4 karakter");
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      localStorage.setItem(ACCESS_CODE_KEY, newCode);
      setIsLoading(false);
      setSuccess(true);
      setNewCode("");
      
      setTimeout(() => {
        setSuccess(false);
      }, 3000);
    }, 500);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto space-y-6">
        <div>
          <h1 className="font-display text-3xl font-bold uppercase tracking-wide mb-2 flex items-center gap-2">
            <Settings className="w-8 h-8 text-primary" />
            Admin Settings
          </h1>
          <p className="text-muted-foreground">Kelola konfigurasi tracker</p>
        </div>

        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span>Ubah Kode Akses Tracker</span>
            </CardTitle>
            <CardDescription>
              Hanya Admin yang bisa mengubah kode akses. Perubahan akan berlaku langsung.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="uppercase text-xs font-bold tracking-widest text-muted-foreground">
                Kode Akses Baru
              </Label>
              <Input
                type="password"
                placeholder="Minimal 4 karakter"
                value={newCode}
                onChange={(e) => setNewCode(e.target.value)}
                className="bg-background/50 border-primary/20 focus:border-primary text-lg tracking-wide"
                maxLength={20}
                disabled={isLoading}
              />
              <p className="text-xs text-muted-foreground">
                Kode ini akan diminta ketika mengakses tracker
              </p>
            </div>

            {error && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-500 text-sm">
                <AlertCircle className="w-4 h-4 shrink-0" />
                {error}
              </div>
            )}

            {success && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-green-500/10 border border-green-500/30 text-green-600 text-sm">
                <Check className="w-4 h-4 shrink-0" />
                Kode akses berhasil diubah!
              </div>
            )}

            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button 
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground uppercase font-bold tracking-wider"
                  disabled={isLoading || !newCode.trim()}
                >
                  {isLoading ? "Menyimpan..." : "Simpan Kode Akses"}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="bg-card border-border">
                <AlertDialogHeader>
                  <AlertDialogTitle className="text-lg font-bold uppercase tracking-wide">Ubah Kode Akses?</AlertDialogTitle>
                  <AlertDialogDescription className="text-sm text-muted-foreground mt-2">
                    Kode akses akan diubah ke: <span className="font-mono font-bold text-foreground">{newCode}</span>
                    <br/>
                    Kode lama tidak akan berlaku lagi.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <div className="flex gap-3">
                  <AlertDialogCancel className="flex-1">Batal</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={handleChangeCode}
                    className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                  >
                    Ubah Kode
                  </AlertDialogAction>
                </div>
              </AlertDialogContent>
            </AlertDialog>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50">
          <CardContent className="pt-6">
            <div className="space-y-3">
              <h3 className="font-bold uppercase tracking-wide text-sm">Informasi Penting:</h3>
              <ul className="text-xs text-muted-foreground space-y-2 list-disc list-inside">
                <li>Setiap user yang baru login harus input kode akses</li>
                <li>Simpan kode akses di tempat aman</li>
                <li>Perubahan langsung berlaku di semua device</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
