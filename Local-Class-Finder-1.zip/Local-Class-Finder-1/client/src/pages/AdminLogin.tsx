import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, AlertCircle } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { login, mockCredentials } from "@/lib/auth";

export function AdminLogin() {
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [activeTab, setActiveTab] = useState("login");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    setTimeout(() => {
      const user = login(username, password);
      if (user) {
        setIsLoading(false);
        setLocation("/clan-dashboard");
      } else {
        setError("Username atau password salah!");
        setIsLoading(false);
      }
    }, 1500);
  };

  // Group credentials by clan
  const credsByClans: Record<string, any[]> = {};
  Object.entries(mockCredentials).forEach(([username, cred]) => {
    if (!credsByClans[cred.clanName]) {
      credsByClans[cred.clanName] = [];
    }
    credsByClans[cred.clanName].push({ username, ...cred });
  });

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-gradient-to-br from-background via-background to-primary/5">
      <div className="w-full max-w-2xl space-y-6">
        <Card className="border-primary/20 bg-card/50 backdrop-blur-sm shadow-2xl shadow-black/50">
          <CardHeader className="text-center space-y-4 pb-6">
            <div className="mx-auto w-16 h-16 rounded-full bg-primary/10 border border-primary/50 flex items-center justify-center text-primary shadow-[0_0_30px_rgba(234,179,8,0.2)]">
              <Shield className="w-8 h-8" />
            </div>
            <div>
              <CardTitle className="font-display text-3xl font-bold tracking-wide uppercase">Clan Login</CardTitle>
              <CardDescription>Multi-Clan Management System</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 bg-background/50 mb-6">
                <TabsTrigger value="login">LOGIN</TabsTrigger>
                <TabsTrigger value="credentials">TEST ACCOUNTS</TabsTrigger>
              </TabsList>

              {/* Login Tab */}
              <TabsContent value="login">
                <form onSubmit={handleLogin} className="space-y-6">
                  <div className="space-y-2">
                    <Label className="uppercase text-xs font-bold tracking-widest text-muted-foreground">Username</Label>
                    <Input 
                      placeholder="admin / ketua / officer / phoenix_leader..." 
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="bg-background/50 border-primary/20 focus:border-primary"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="uppercase text-xs font-bold tracking-widest text-muted-foreground">Password</Label>
                    <Input 
                      type="password" 
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="bg-background/50 border-primary/20 focus:border-primary" 
                    />
                  </div>

                  {error && (
                    <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-500 text-sm">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      {error}
                    </div>
                  )}

                  <Button 
                    className="w-full font-bold uppercase tracking-widest" 
                    size="lg"
                    disabled={isLoading || !username || !password}
                  >
                    {isLoading ? "Authenticating..." : "Login"}
                  </Button>
                </form>
              </TabsContent>

              {/* Credentials Tab */}
              <TabsContent value="credentials">
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {Object.entries(credsByClans).map(([clanName, accounts]) => (
                    <div key={clanName} className="space-y-2 p-3 rounded-lg border border-border bg-background/30">
                      <h3 className="font-display font-bold text-primary uppercase tracking-wide text-sm">{clanName}</h3>
                      <div className="space-y-2 text-xs font-mono">
                        {accounts.map((acc) => (
                          <div key={acc.username} className="flex justify-between p-2 bg-background/50 rounded border border-border/50">
                            <div>
                              <span className="text-muted-foreground">Username:</span>
                              <span className="text-foreground ml-2 font-bold">{acc.username}</span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Pass:</span>
                              <span className="text-foreground ml-2 font-bold">{acc.password}</span>
                            </div>
                            <div>
                              <span className="px-2 py-1 rounded text-white" style={{
                                backgroundColor: acc.role === "Leader" ? "hsl(31, 93%, 35%)" : 
                                                acc.role === "Officer" ? "hsl(217, 91%, 60%)" : "hsl(0, 84%, 60%)"
                              }}>
                                {acc.role}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <Card className="border-border/30 bg-card/30 backdrop-blur-sm p-4">
          <p className="text-xs text-muted-foreground text-center">
            <span className="text-primary font-bold">👑 Admin:</span> Full access semua clan<br/>
            <span className="text-orange-500 font-bold">👸 Ketua:</span> Manage members clan sendiri<br/>
            <span className="text-blue-500 font-bold">⚔️ Officer:</span> View stats clan sendiri
          </p>
        </Card>
      </div>
    </div>
  );
}
