import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Copy, Bot, MessageSquare, AlertCircle, Loader } from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner";

export function DiscordSettings() {
  const [botStatus, setBotStatus] = useState<"connected" | "disconnected" | "loading">("loading");
  const [webhookUrl, setWebhookUrl] = useState("");
  const [guildId, setGuildId] = useState("default-clan");
  const [isLoading, setIsLoading] = useState(false);
  const [isSendingTest, setIsSendingTest] = useState(false);
  const [settings, setSettings] = useState({
    spawnAlerts15min: true,
    spawnAlertsNow: true,
    killLogs: true,
    dailySummary: false,
  });

  // Check bot status on mount
  useEffect(() => {
    checkBotStatus();
    loadDiscordConfig();
  }, []);

  const checkBotStatus = async () => {
    try {
      const response = await fetch("/api/discord/status");
      const data = await response.json();
      setBotStatus(data.ready ? "connected" : "disconnected");
    } catch (error) {
      setBotStatus("disconnected");
    }
  };

  const loadDiscordConfig = async () => {
    try {
      const response = await fetch(`/api/discord/config/${guildId}`);
      const data = await response.json();
      if (data.webhookUrl) setWebhookUrl(data.webhookUrl);
      if (data.spawnAlerts15min !== undefined) {
        setSettings({
          spawnAlerts15min: data.spawnAlerts15min,
          spawnAlertsNow: data.spawnAlertsNow,
          killLogs: data.killLogs,
          dailySummary: data.dailySummary,
        });
      }
    } catch (error) {
      console.error("Failed to load Discord config:", error);
    }
  };

  const handleSaveConfig = async () => {
    if (!webhookUrl.trim()) {
      toast.error("Webhook URL diperlukan");
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch("/api/discord/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          guildId,
          webhookUrl,
          ...settings,
        }),
      });

      if (response.ok) {
        // Save webhook URL to localStorage for kill reports
        localStorage.setItem("discord_webhook_url", webhookUrl);
        localStorage.setItem("discord_guild_id", guildId);
        
        toast.success("Konfigurasi Discord berhasil disimpan!");
        await loadDiscordConfig();
      } else {
        toast.error("Gagal menyimpan konfigurasi");
      }
    } catch (error) {
      toast.error("Terjadi kesalahan saat menyimpan");
    } finally {
      setIsLoading(false);
    }
  };

  const handleTestNotification = async () => {
    if (!webhookUrl.trim()) {
      toast.error("Masukkan Webhook URL terlebih dahulu");
      return;
    }

    setIsSendingTest(true);
    try {
      const response = await fetch("/api/discord/test-notification", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          webhookUrl,
          message: "Test notifikasi dari L2M Tracker - Integrasi Discord berhasil!",
        }),
      });

      const data = await response.json();
      if (data.success) {
        toast.success("Pesan tes berhasil dikirim ke Discord!");
      } else {
        toast.error("Gagal mengirim pesan: " + data.message);
      }
    } catch (error) {
      toast.error("Gagal mengirim pesan test");
    } finally {
      setIsSendingTest(false);
    }
  };

  const toggleSetting = (key: keyof typeof settings) => {
    setSettings((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(webhookUrl);
    toast.success("Webhook URL disalin");
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="font-display text-4xl font-bold uppercase tracking-tight mb-2">Integrasi Discord</h1>
        <p className="text-muted-foreground">Hubungkan server Discord clan Anda untuk menerima notifikasi boss secara real-time.</p>
      </div>

      <div className="grid gap-6">
        {/* Status Card */}
        <Card className={`border-l-4 ${botStatus === "connected" ? "border-l-green-500 bg-green-500/5" : "border-l-yellow-500 bg-yellow-500/5"}`}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div className="space-y-1">
              <CardTitle className="font-display text-xl uppercase">Status Bot</CardTitle>
              <CardDescription>Pemeriksaan konektivitas sistem</CardDescription>
            </div>
            <Badge 
              className={`uppercase tracking-widest ${botStatus === "connected" ? "bg-green-500/20 text-green-500" : "bg-yellow-500/20 text-yellow-500"}`}
            >
              {botStatus === "loading" && "Cek..."}
              {botStatus === "connected" && "Terhubung"}
              {botStatus === "disconnected" && "Terputus"}
            </Badge>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              {botStatus === "connected" ? (
                <>
                  <Check className="w-4 h-4 text-green-500" />
                  <span>Bot Discord terhubung ke jaringan</span>
                </>
              ) : (
                <>
                  <AlertCircle className="w-4 h-4 text-yellow-500" />
                  <span>Bot akan siap setelah Anda menyimpan konfigurasi webhook</span>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="font-display text-xl uppercase">Konfigurasi Server</CardTitle>
            <CardDescription>Setup channel notifikasi Anda</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="p-4 rounded-lg border border-border bg-background/50 space-y-3">
                <div className="flex items-center gap-2 text-primary font-bold uppercase text-sm tracking-wider">
                  <Bot className="w-4 h-4" />
                  ID Clan/Guild
                </div>
                <p className="text-xs text-muted-foreground">
                  Identifikasi unik untuk clan Anda
                </p>
                <input 
                  className="w-full bg-background border border-border rounded px-3 py-2 text-sm text-foreground"
                  placeholder="default-clan"
                  value={guildId}
                  onChange={(e) => setGuildId(e.target.value)}
                  data-testid="input-guild-id"
                />
              </div>

              <div className="p-4 rounded-lg border border-border bg-background/50 space-y-3">
                <div className="flex items-center gap-2 text-primary font-bold uppercase text-sm tracking-wider">
                  <MessageSquare className="w-4 h-4" />
                  Webhook URL
                </div>
                <p className="text-xs text-muted-foreground">
                  URL Webhook dari channel Discord Anda
                </p>
                <div className="flex gap-2">
                  <input 
                    className="flex-1 bg-background border border-border rounded px-3 py-2 text-xs" 
                    placeholder="https://discord.com/api/webhooks/..." 
                    value={webhookUrl}
                    onChange={(e) => setWebhookUrl(e.target.value)}
                    data-testid="input-webhook-url"
                  />
                  <Button 
                    size="icon" 
                    variant="ghost" 
                    className="h-9 w-9"
                    onClick={copyToClipboard}
                    data-testid="button-copy-webhook"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-border">
              <h3 className="text-sm font-medium mb-4 uppercase tracking-wide">Pengaturan Notifikasi</h3>
              <div className="space-y-4">
                {[
                  { key: "spawnAlerts15min", label: "Peringatan Spawn (15 menit sebelum)" },
                  { key: "spawnAlertsNow", label: "Peringatan Spawn (Sekarang)" },
                  { key: "killLogs", label: "Log Konfirmasi Kill" },
                  { key: "dailySummary", label: "Ringkasan Harian" },
                ].map(({ key, label }) => (
                  <div key={key} className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">{label}</span>
                    <button
                      onClick={() => toggleSetting(key as keyof typeof settings)}
                      className={`h-5 w-9 rounded-full p-1 transition-colors ${
                        settings[key as keyof typeof settings] ? "bg-primary" : "bg-muted"
                      }`}
                      data-testid={`toggle-${key}`}
                    >
                      <div
                        className={`h-3 w-3 rounded-full bg-white transition-transform ${
                          settings[key as keyof typeof settings] ? "ml-auto" : ""
                        }`}
                      />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-border flex gap-3">
              <Button 
                onClick={handleSaveConfig}
                disabled={isLoading}
                className="bg-primary hover:bg-primary/90 text-primary-foreground uppercase font-bold tracking-wider"
                data-testid="button-save-config"
              >
                {isLoading ? "Menyimpan..." : "Simpan Konfigurasi"}
              </Button>
              <Button 
                onClick={handleTestNotification}
                disabled={isSendingTest || !webhookUrl}
                variant="outline"
                data-testid="button-test-notification"
              >
                {isSendingTest ? (
                  <>
                    <Loader className="w-4 h-4 mr-2 animate-spin" />
                    Mengirim...
                  </>
                ) : (
                  "Test Notifikasi"
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
