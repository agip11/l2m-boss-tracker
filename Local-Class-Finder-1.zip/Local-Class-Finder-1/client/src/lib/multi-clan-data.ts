import { ClanMember } from "./clans";

export interface KillRecord {
  id: string;
  bossName: string;
  region: string;
  killTime: Date;
  participants: string[];
  reportedBy: string;
}

export interface Clan {
  id: string;
  name: string;
  leader: string;
  members: ClanMember[];
  killRecords: KillRecord[];
  createdDate: string;
}

interface DbClan {
  id: string;
  name: string;
  leader: string;
  createdDate: string;
}

interface DbClanMember {
  id: string;
  clanId: string;
  name: string;
  role: string;
  joinDate: string;
}

interface DbKillRecord {
  id: string;
  clanId: string;
  bossName: string;
  region: string;
  killTime: number;
  participants: string;
  reportedBy: string;
}

// In-memory cache that syncs with database
let clanCache: Map<string, Clan> = new Map();
let initialized = false;
const INITIALIZED_KEY = "clan_data_initialized_v2";

// Default clans if database is empty
const defaultClans: Clan[] = [
  {
    id: "clan_001",
    name: "Dragon Slayers",
    leader: "Admin",
    createdDate: "2024-01-15",
    members: [
      { id: "m1", name: "Admin Leader", role: "Leader", joinDate: "2024-01-15" },
      { id: "m2", name: "Officer Warrior", role: "Officer", joinDate: "2024-02-20" },
      { id: "m3", name: "Knight Assassin", role: "Member", joinDate: "2024-03-10" },
    ],
    killRecords: []
  },
  {
    id: "clan_002",
    name: "Phoenix Rising",
    leader: "Phoenix Leader",
    createdDate: "2024-02-10",
    members: [
      { id: "m7", name: "Phoenix Leader", role: "Leader", joinDate: "2024-02-10" },
      { id: "m8", name: "Phoenix Officer", role: "Officer", joinDate: "2024-02-15" },
    ],
    killRecords: []
  },
  {
    id: "clan_003",
    name: "Shadow Hunters",
    leader: "Shadow Master",
    createdDate: "2024-03-05",
    members: [
      { id: "m12", name: "Shadow Master", role: "Leader", joinDate: "2024-03-05" },
      { id: "m13", name: "Shadow Officer", role: "Officer", joinDate: "2024-03-10" },
    ],
    killRecords: []
  },
  {
    id: "clan_004",
    name: "Holy Knights",
    leader: "Holy Lord",
    createdDate: "2024-04-01",
    members: [
      { id: "m18", name: "Holy Lord", role: "Leader", joinDate: "2024-04-01" },
      { id: "m19", name: "Holy Officer", role: "Officer", joinDate: "2024-04-05" },
    ],
    killRecords: []
  }
];

async function initializeClanData(): Promise<void> {
  if (initialized) return;
  
  try {
    // Check if we've already initialized data in this browser
    const hasInitialized = localStorage.getItem(INITIALIZED_KEY) === "true";
    
    // Fetch existing clans from API
    const response = await fetch("/api/clans");
    const dbClans: DbClan[] = await response.json();
    
    if (dbClans.length === 0 && !hasInitialized) {
      // First time - seed default clans
      console.log("[CLAN-INIT] Seeding default clans...");
      for (const clan of defaultClans) {
        // Save clan
        await fetch("/api/clans", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            id: clan.id,
            name: clan.name,
            leader: clan.leader,
            createdDate: clan.createdDate
          })
        });
        
        // Save members
        for (const member of clan.members) {
          await fetch(`/api/clans/${clan.id}/members`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              id: member.id,
              name: member.name,
              role: member.role,
              joinDate: member.joinDate
            })
          });
        }
        
        clanCache.set(clan.id, clan);
      }
      localStorage.setItem(INITIALIZED_KEY, "true");
    } else {
      // Load existing data from database
      for (const dbClan of dbClans) {
        // Fetch members for this clan
        const membersRes = await fetch(`/api/clans/${dbClan.id}/members`);
        const dbMembers: DbClanMember[] = await membersRes.json();
        
        // Fetch kill records for this clan
        const killsRes = await fetch(`/api/clans/${dbClan.id}/kills`);
        const dbKills: DbKillRecord[] = await killsRes.json();
        
        const clan: Clan = {
          id: dbClan.id,
          name: dbClan.name,
          leader: dbClan.leader,
          createdDate: dbClan.createdDate,
          members: dbMembers.map(m => ({
            id: m.id,
            name: m.name,
            role: m.role as "Leader" | "Officer" | "Member",
            joinDate: m.joinDate
          })),
          killRecords: dbKills.map(k => ({
            id: k.id,
            bossName: k.bossName,
            region: k.region,
            killTime: new Date(k.killTime),
            participants: JSON.parse(k.participants),
            reportedBy: k.reportedBy
          }))
        };
        
        clanCache.set(clan.id, clan);
      }
    }
    
    initialized = true;
    console.log(`[CLAN-INIT] Loaded ${clanCache.size} clans from database`);
  } catch (error) {
    console.error("[CLAN-INIT] Error initializing clan data:", error);
    // Fallback to defaults if API fails
    for (const clan of defaultClans) {
      clanCache.set(clan.id, clan);
    }
    initialized = true;
  }
}

// Initialize on module load
initializeClanData();

// Get clan by ID
export function getClanById(clanId: string): Clan | undefined {
  return clanCache.get(clanId);
}

// Get all clans (for admin view)
export function getAllClans(): Clan[] {
  return Array.from(clanCache.values());
}

// Get clan members by clan ID
export function getClanMembers(clanId: string): ClanMember[] {
  const clan = getClanById(clanId);
  return clan ? clan.members : [];
}

// Get clan kill records by clan ID
export function getClanKillRecords(clanId: string): KillRecord[] {
  const clan = getClanById(clanId);
  return clan ? clan.killRecords : [];
}

// Get all members for a clan
export function getAllClanMembers(clanId: string): ClanMember[] {
  return getClanMembers(clanId);
}

// Add clan member
export function addClanMember(clanId: string, member: ClanMember): void {
  const clan = clanCache.get(clanId);
  if (clan) {
    clan.members.push(member);
    clanCache.set(clanId, clan);
    
    // Persist to API
    fetch(`/api/clans/${clanId}/members`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: member.id,
        name: member.name,
        role: member.role,
        joinDate: member.joinDate
      })
    }).catch(err => console.error("Failed to persist member:", err));
  }
}

// Delete clan member
export function deleteClanMember(clanId: string, memberId: string): void {
  const clan = clanCache.get(clanId);
  if (clan) {
    clan.members = clan.members.filter(m => m.id !== memberId);
    clanCache.set(clanId, clan);
    
    // Persist to API
    fetch(`/api/clans/${clanId}/members/${memberId}`, {
      method: "DELETE"
    }).catch(err => console.error("Failed to delete member:", err));
  }
}

// Get clan display name
export function getClanDisplayName(clanId: string): string {
  const clan = getClanById(clanId);
  return clan ? clan.name : "Unknown Clan";
}

// Update clan name
export function updateClanName(clanId: string, newName: string): void {
  const clan = clanCache.get(clanId);
  if (clan) {
    clan.name = newName;
    clanCache.set(clanId, clan);
    
    // Persist to API
    fetch(`/api/clans/${clanId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: newName })
    }).catch(err => console.error("Failed to update clan name:", err));
  }
}

// Add kill record
export function addKillRecord(clanId: string, record: KillRecord): void {
  const clan = clanCache.get(clanId);
  if (clan) {
    clan.killRecords.push(record);
    clanCache.set(clanId, clan);
    
    // Persist to API
    fetch(`/api/clans/${clanId}/kills`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: record.id,
        bossName: record.bossName,
        region: record.region,
        killTime: record.killTime.getTime(),
        participants: JSON.stringify(record.participants),
        reportedBy: record.reportedBy
      })
    }).catch(err => console.error("Failed to persist kill record:", err));
  }
}

// Update kill record participants
export function updateClanKillRecord(clanId: string, killId: string, participants: string[]): void {
  const clan = clanCache.get(clanId);
  if (clan) {
    const record = clan.killRecords.find(k => k.id === killId);
    if (record) {
      record.participants = participants;
      clanCache.set(clanId, clan);
      
      // Persist to API
      fetch(`/api/kills/${killId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ participants: JSON.stringify(participants) })
      }).catch(err => console.error("Failed to update kill record:", err));
    }
  }
}

// Get modified kill record (returns null - modifications are now in the record itself)
export function getModifiedKillRecord(_clanId: string, _killId: string): { participants: string[] } | null {
  return null;
}

// Re-initialize data from database (call after restart)
export async function refreshClanData(): Promise<void> {
  initialized = false;
  clanCache.clear();
  await initializeClanData();
}
