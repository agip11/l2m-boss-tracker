import { BOSS_DATA } from "./l2m-data";

const AUTO_SPAWN_TIMEOUT = 10 * 60 * 1000;
const INITIALIZED_KEY = "boss_state_initialized_v2";

export interface BossState {
  bossId: string;
  lastKilledTime: number | null;
  autoSpawnedAt?: number;
}

// In-memory cache for synchronous access
const cache = new Map<string, BossState>();

async function fetchAndCache(bossId: string): Promise<BossState> {
  try {
    const response = await fetch(`/api/boss-state/${bossId}`);
    if (!response.ok) throw new Error("Failed to fetch");
    const data = await response.json();
    // Always clear autoSpawnedAt when fetching from server (it's transient, not persistent)
    const cleaned = { ...data, autoSpawnedAt: undefined };
    cache.set(bossId, cleaned);
    return cleaned;
  } catch {
    return { bossId, lastKilledTime: null };
  }
}

async function initializeDemoData() {
  try {
    const now = new Date();
    
    for (const boss of BOSS_DATA) {
      const index = BOSS_DATA.indexOf(boss);
      const minHoursSinceKill = Math.max(boss.respawnTimeHours + 0.25, 4);
      const hoursSinceKill = minHoursSinceKill + (index % 8);
      const killTime = new Date(now.getTime() - hoursSinceKill * 60 * 60 * 1000);
      
      const state: BossState = {
        bossId: boss.id,
        lastKilledTime: killTime.getTime(),
      };
      
      try {
        const response = await fetch(`/api/boss-state`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(state),
        });
        if (response.ok) {
          const saved = await response.json();
          cache.set(boss.id, saved);
        }
      } catch (e) {
        console.error(`Failed to initialize ${boss.id}:`, e);
      }
      
      console.log(`[INIT] ${boss.id}: killed ${hoursSinceKill.toFixed(2)}h ago (respawn: ${boss.respawnTimeHours}h)`);
    }

    console.log(`[INIT] Demo data initialized for ${BOSS_DATA.length} bosses`);
  } catch (e) {
    console.error("Failed to initialize demo data:", e);
  }
}

// Initialize demo data on first load
try {
  const hasEverInitialized = localStorage.getItem(INITIALIZED_KEY) === "true";
  
  if (!hasEverInitialized) {
    localStorage.setItem(INITIALIZED_KEY, "true");
    initializeDemoData();
    console.log("[INIT] First load - initializing with demo data");
  } else {
    // Preload cache from server
    for (const boss of BOSS_DATA) {
      fetchAndCache(boss.id);
    }
  }
} catch (e) {
  console.error("Error during initialization:", e);
}

function getCachedState(bossId: string): BossState {
  const cached = cache.get(bossId);
  if (cached) return cached;
  
  // Not in cache, fetch async in background
  fetchAndCache(bossId);
  
  // Return empty state immediately
  return { bossId, lastKilledTime: null };
}

async function saveStateToServer(state: BossState): Promise<void> {
  try {
    const response = await fetch(`/api/boss-state`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(state),
    });
    
    if (!response.ok) {
      const errorData = await response.text();
      console.error(`[ERROR] Failed to save ${state.bossId}:`, response.status, errorData);
      return;
    }
    
    cache.set(state.bossId, state);
  } catch (e) {
    console.error("Failed to save boss state:", e);
  }
}

async function updateStateOnServer(bossId: string, updates: Partial<BossState>): Promise<void> {
  try {
    const response = await fetch(`/api/boss-state/${bossId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updates),
    });
    
    if (!response.ok) {
      const errorData = await response.text();
      console.error(`[ERROR] Failed to update ${bossId}:`, response.status, errorData);
      return;
    }
    
    const current = cache.get(bossId) || { bossId, lastKilledTime: null };
    cache.set(bossId, { ...current, ...updates });
  } catch (e) {
    console.error("Failed to update boss state:", e);
  }
}

export function getLastKilledTime(bossId: string): Date | null {
  const state = getCachedState(bossId);
  return state.lastKilledTime ? new Date(state.lastKilledTime) : null;
}

export function setLastKilledTime(bossId: string, time: Date) {
  const state = getCachedState(bossId);
  state.lastKilledTime = time.getTime();
  state.autoSpawnedAt = undefined;
  cache.set(bossId, state);
  updateStateOnServer(bossId, state);
}

export function checkAndHandleAutoSpawn(
  bossId: string,
  respawnTimeHours: number
): Date | null {
  const state = getCachedState(bossId);
  
  if (!state.lastKilledTime) {
    return null;
  }

  if (state.autoSpawnedAt) {
    const lastKilled = new Date(state.lastKilledTime);
    const expectedSpawnTime = new Date(lastKilled.getTime() + respawnTimeHours * 60 * 60 * 1000);
    return expectedSpawnTime;
  }

  const lastKilled = new Date(state.lastKilledTime);
  const expectedSpawnTime = new Date(lastKilled.getTime() + respawnTimeHours * 60 * 60 * 1000);
  const now = new Date();

  const timeoutTime = new Date(expectedSpawnTime.getTime() + AUTO_SPAWN_TIMEOUT);
  
  if (bossId === "gludio-6" || bossId === "dion-4") {
    const timeDiff = now.getTime() - timeoutTime.getTime();
    console.log(`[DEBUG ${bossId}] lastKilled=${lastKilled.toLocaleTimeString()}, expectedSpawn=${expectedSpawnTime.toLocaleTimeString()}, now=${now.toLocaleTimeString()}, timeoutTime=${timeoutTime.toLocaleTimeString()}, timeDiff=${(timeDiff/1000).toFixed(0)}s, shouldTrigger=${now >= timeoutTime}`);
  }
  
  if (now >= timeoutTime) {
    state.lastKilledTime = expectedSpawnTime.getTime();
    state.autoSpawnedAt = now.getTime();
    cache.set(bossId, state);
    // Only save lastKilledTime to server, not autoSpawnedAt (it's transient)
    updateStateOnServer(bossId, { lastKilledTime: expectedSpawnTime.getTime() });
    const nextSpawn = new Date(expectedSpawnTime.getTime() + respawnTimeHours * 60 * 60 * 1000);
    console.log(`[AUTO-RELOG] ${bossId}: Triggered auto-spawn at ${now.toLocaleTimeString()}, next spawn: ${nextSpawn.toLocaleTimeString()}`);
    return nextSpawn;
  }

  return expectedSpawnTime;
}

export function getNextSpawnTime(
  bossId: string,
  respawnTimeHours: number
): Date | null {
  const lastKilled = getLastKilledTime(bossId);
  if (!lastKilled) {
    return null;
  }

  const nextSpawn = new Date(lastKilled.getTime() + respawnTimeHours * 60 * 60 * 1000);
  const now = new Date();
  const diff = nextSpawn.getTime() - now.getTime();
  
  if (diff < 0) {
    const autoSpawnResult = checkAndHandleAutoSpawn(bossId, respawnTimeHours);
    if (autoSpawnResult) {
      return autoSpawnResult;
    }
    
    if (diff < -3600000) {
      console.warn(`Boss ${bossId}: force reset (stuck > 1h)`);
      const newKillTime = new Date(now.getTime() - respawnTimeHours * 60 * 60 * 1000);
      const state = getCachedState(bossId);
      state.lastKilledTime = newKillTime.getTime();
      state.autoSpawnedAt = undefined;
      cache.set(bossId, state);
      updateStateOnServer(bossId, state);
      return new Date(newKillTime.getTime() + respawnTimeHours * 60 * 60 * 1000);
    }
    
    return null;
  }
  
  return nextSpawn;
}

export function clearBossState(bossId: string): void {
  const state = getCachedState(bossId);
  state.lastKilledTime = null;
  state.autoSpawnedAt = undefined;
  cache.set(bossId, state);
  updateStateOnServer(bossId, state);
}

export async function clearAllBossState(): Promise<void> {
  try {
    const bossList = BOSS_DATA.map(boss => boss.id);
    
    // Reset all boss states in database first
    const response = await fetch(`/api/boss-state/reset/all`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ bossList }),
    });

    if (!response.ok) {
      throw new Error("Failed to reset boss states on server");
    }

    // Then clear local cache
    for (const boss of BOSS_DATA) {
      cache.set(boss.id, { bossId: boss.id, lastKilledTime: null });
    }
    
    console.log(`[RESET] Successfully reset ${bossList.length} bosses in database and cache.`);
  } catch (e) {
    console.error("Failed to reset all boss states:", e);
    throw e; // Re-throw so caller knows it failed
  }
}
