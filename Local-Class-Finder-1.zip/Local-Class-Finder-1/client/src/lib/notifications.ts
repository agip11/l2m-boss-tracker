// Text-to-Speech notification utility
export async function playSpawnNotification(bossName: string, minutesLeft: number) {
  // Check if browser supports speech synthesis
  if (!('speechSynthesis' in window)) {
    console.warn("Speech synthesis not supported in this browser");
    return;
  }

  const utterance = new SpeechSynthesisUtterance();
  
  if (minutesLeft === 0) {
    utterance.text = `${bossName} can spawn now!`;
  } else if (minutesLeft === 1) {
    utterance.text = `${bossName} can spawn in 1 minute`;
  } else {
    utterance.text = `${bossName} can spawn in ${minutesLeft} minutes`;
  }

  // Set voice properties
  utterance.rate = 1.0;
  utterance.pitch = 1.0;
  utterance.volume = 1.0;
  utterance.lang = 'en-US';

  // Play the notification
  window.speechSynthesis.cancel(); // Cancel any ongoing speech
  window.speechSynthesis.speak(utterance);
}

export async function playAudioAlert() {
  // Create a simple beep sound using Web Audio API
  try {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    // Create a short beep
    oscillator.frequency.value = 800;
    oscillator.type = 'sine';

    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);

    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.5);
  } catch (error) {
    console.error("Failed to play audio alert:", error);
  }
}

// Track which notifications we've already played to avoid duplicates
const notificationCache = new Map<string, number>();

export function shouldPlayNotification(bossId: string, minutesLeft: number): boolean {
  const key = `${bossId}-${minutesLeft}`;
  const lastTriggered = notificationCache.get(key);
  const now = Date.now();

  // Only trigger if we haven't triggered this notification in the last minute
  if (lastTriggered && now - lastTriggered < 60000) {
    return false;
  }

  notificationCache.set(key, now);
  return true;
}
