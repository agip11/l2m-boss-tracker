export interface Boss {
  id: string;
  name: string;
  region: string;
  respawnTimeHours: number;
  spawnChance: number; // Percentage
  level?: number;
}

export const BOSS_DATA: Boss[] = [
  // GLUDIO
  { id: "gludio-1", name: "Tromba", region: "Gludio", respawnTimeHours: 7, spawnChance: 50 },
  { id: "gludio-2", name: "Chertuba", region: "Gludio", respawnTimeHours: 6, spawnChance: 50 },
  { id: "gludio-3", name: "Kelsus", region: "Gludio", respawnTimeHours: 10, spawnChance: 50 },
  { id: "gludio-4", name: "Queen Ant", region: "Gludio", respawnTimeHours: 6, spawnChance: 33 },
  { id: "gludio-5", name: "Savan", region: "Gludio", respawnTimeHours: 12, spawnChance: 100 },
  { id: "gludio-6", name: "Basila", region: "Gludio", respawnTimeHours: 4, spawnChance: 50 },

  // DION
  { id: "dion-1", name: "Enkura", region: "Dion", respawnTimeHours: 6, spawnChance: 50 },
  { id: "dion-2", name: "Talakin", region: "Dion", respawnTimeHours: 10, spawnChance: 100 },
  { id: "dion-3", name: "Gahareth", region: "Dion", respawnTimeHours: 9, spawnChance: 50 },
  { id: "dion-4", name: "Felis", region: "Dion", respawnTimeHours: 3, spawnChance: 50 },
  { id: "dion-5", name: "Pan Dra'eed", region: "Dion", respawnTimeHours: 12, spawnChance: 100 },
  { id: "dion-6", name: "Sarka", region: "Dion", respawnTimeHours: 10, spawnChance: 100 },
  { id: "dion-7", name: "Timitris", region: "Dion", respawnTimeHours: 8, spawnChance: 100 },
  { id: "dion-8", name: "Valefar", region: "Dion", respawnTimeHours: 6, spawnChance: 50 },
  { id: "dion-9", name: "Stonegeist", region: "Dion", respawnTimeHours: 7, spawnChance: 100 },
  { id: "dion-10", name: "Mutated Cruma", region: "Dion", respawnTimeHours: 8, spawnChance: 100 },
  { id: "dion-11", name: "Contaminated Cruma", region: "Dion", respawnTimeHours: 8, spawnChance: 100 },
  { id: "dion-12", name: "Katan", region: "Dion", respawnTimeHours: 10, spawnChance: 100 },
  { id: "dion-13", name: "Core Susceptor", region: "Dion", respawnTimeHours: 10, spawnChance: 33 },

  // GIRAN
  { id: "giran-1", name: "Pan Narod", region: "Giran", respawnTimeHours: 5, spawnChance: 50 },
  { id: "giran-2", name: "Medusa", region: "Giran", respawnTimeHours: 10, spawnChance: 100 },
  { id: "giran-3", name: "Matura", region: "Giran", respawnTimeHours: 6, spawnChance: 50 },
  { id: "giran-4", name: "Breka", region: "Giran", respawnTimeHours: 6, spawnChance: 50 },
  { id: "giran-5", name: "Black Lily", region: "Giran", respawnTimeHours: 12, spawnChance: 100 },
  { id: "giran-6", name: "Behemoth", region: "Giran", respawnTimeHours: 9, spawnChance: 100 },
  { id: "giran-7", name: "Dragon Beast", region: "Giran", respawnTimeHours: 12, spawnChance: 33 },

  // OREN
  { id: "oren-1", name: "Talkin", region: "Oren", respawnTimeHours: 8, spawnChance: 33 },
  { id: "oren-2", name: "Selu", region: "Oren", respawnTimeHours: 12, spawnChance: 33 },
  { id: "oren-3", name: "Balbo", region: "Oren", respawnTimeHours: 12, spawnChance: 33 },
  { id: "oren-4", name: "Timiniel", region: "Oren", respawnTimeHours: 8, spawnChance: 100 },
  { id: "oren-5", name: "Coroon", region: "Oren", respawnTimeHours: 12, spawnChance: 100 },
  { id: "oren-6", name: "Repiro", region: "Oren", respawnTimeHours: 7, spawnChance: 50 },
  { id: "oren-7", name: "Orfen", region: "Oren", respawnTimeHours: 24, spawnChance: 33 },

  // ADEN
  { id: "aden-1", name: "Mirror of Oblivion", region: "Aden", respawnTimeHours: 11, spawnChance: 100 },
  { id: "aden-2", name: "Hisilrome", region: "Aden", respawnTimeHours: 6, spawnChance: 50 },
  { id: "aden-3", name: "Landor/Randor", region: "Aden", respawnTimeHours: 9, spawnChance: 100 },
  { id: "aden-4", name: "Glaki", region: "Aden", respawnTimeHours: 8, spawnChance: 100 },
];
