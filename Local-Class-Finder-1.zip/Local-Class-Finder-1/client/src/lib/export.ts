import { ClanMember } from "./clans";

interface KillRecord {
  id: string;
  bossName: string;
  region: string;
  killTime: Date;
  participants: string[];
  reportedBy: string;
}

export function exportToCSV(members: ClanMember[], kills: KillRecord[]) {
  let csv = "CLAN DATA EXPORT\n\n";
  
  // Member Participation Summary
  csv += "MEMBER PARTICIPATION SUMMARY\n";
  csv += "Name,Role,Total Kills Participated,Kill Reports\n";
  
  members.forEach(m => {
    const killCount = kills.filter(k => k.participants.includes(m.id)).length;
    const reportCount = kills.filter(k => k.reportedBy === m.id).length;
    csv += `"${m.name}",${m.role},${killCount},${reportCount}\n`;
  });
  
  csv += "\n\nMEMBERS\n";
  csv += "ID,Name,Role,Join Date\n";
  members.forEach(m => {
    csv += `${m.id},"${m.name}",${m.role},"${m.joinDate}"\n`;
  });
  
  csv += "\n\nKILL RECORDS\n";
  csv += "ID,Boss Name,Region,Kill Time,Reported By,Participants\n";
  kills.forEach(k => {
    const killDate = k.killTime instanceof Date ? k.killTime.toISOString() : k.killTime;
    const reportedMember = members.find(m => m.id === k.reportedBy);
    const participantNames = k.participants
      .map(pid => members.find(m => m.id === pid)?.name || pid)
      .join("; ");
    
    csv += `${k.id},"${k.bossName}","${k.region}","${killDate}","${reportedMember?.name || 'Unknown'}","${participantNames}"\n`;
  });

  return csv;
}

export function exportToJSON(members: ClanMember[], kills: KillRecord[]) {
  const data = {
    exportDate: new Date().toISOString(),
    members,
    killRecords: kills
  };
  return JSON.stringify(data, null, 2);
}

export function downloadFile(content: string, filename: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.URL.revokeObjectURL(url);
}
