import potteryImg from "@assets/generated_images/diverse_group_enjoying_a_pottery_workshop_in_a_bright_studio..png";
import cookingImg from "@assets/generated_images/hands_kneading_dough_in_a_cooking_class..png";
import yogaImg from "@assets/generated_images/outdoor_yoga_class_in_a_park..png";
import codingImg from "@assets/generated_images/modern_coding_workshop_in_an_office..png";

export type Category = "Art & Craft" | "Food & Drink" | "Health & Wellness" | "Technology" | "Music" | "Outdoors";

export interface Workshop {
  id: string;
  title: string;
  category: Category;
  price: number;
  date: string;
  time: string;
  duration: string;
  location: string;
  image: string;
  rating: number;
  reviews: number;
  description: string;
  instructor: {
    name: string;
    avatar: string;
    bio: string;
  };
  spotsLeft: number;
  tags: string[];
}

export const workshops: Workshop[] = [
  {
    id: "1",
    title: "Sunset Pottery Wheel Throwing",
    category: "Art & Craft",
    price: 65,
    date: "2024-06-15",
    time: "18:00",
    duration: "2.5 hours",
    location: "Clay & Co Studio, Downtown",
    image: potteryImg,
    rating: 4.9,
    reviews: 128,
    description: "Learn the basics of throwing on the potter's wheel in this relaxing evening workshop. We'll cover centering, opening, and pulling walls to create your own bowls or cups. All materials and firing included.",
    instructor: {
      name: "Sarah Chen",
      avatar: "https://i.pravatar.cc/150?u=sarah",
      bio: "Ceramic artist with 10 years of teaching experience."
    },
    spotsLeft: 3,
    tags: ["Beginner Friendly", "Materials Included", "Small Group"]
  },
  {
    id: "2",
    title: "Artisan Sourdough Masterclass",
    category: "Food & Drink",
    price: 85,
    date: "2024-06-16",
    time: "10:00",
    duration: "4 hours",
    location: "The Rustic Kitchen",
    image: cookingImg,
    rating: 4.8,
    reviews: 95,
    description: "Master the art of sourdough bread making. Learn about starters, fermentation, folding techniques, and scoring. You'll take home your own starter and a loaf ready to bake.",
    instructor: {
      name: "Marcus Rossi",
      avatar: "https://i.pravatar.cc/150?u=marcus",
      bio: "Former head baker at Levant."
    },
    spotsLeft: 5,
    tags: ["Hands-on", "Take-home Kit", "Lunch Included"]
  },
  {
    id: "3",
    title: "Sunrise Park Yoga Flow",
    category: "Health & Wellness",
    price: 20,
    date: "2024-06-17",
    time: "07:00",
    duration: "1 hour",
    location: "Central Park, North Lawn",
    image: yogaImg,
    rating: 5.0,
    reviews: 42,
    description: "Start your day with a revitalizing Vinyasa flow surrounded by nature. Suitable for all levels. Bring your own mat and water bottle.",
    instructor: {
      name: "Emma Wilson",
      avatar: "https://i.pravatar.cc/150?u=emma",
      bio: "Certified RYT-500 Yoga Instructor."
    },
    spotsLeft: 12,
    tags: ["Outdoor", "All Levels", "Morning"]
  },
  {
    id: "4",
    title: "Intro to React & Frontend Dev",
    category: "Technology",
    price: 45,
    date: "2024-06-18",
    time: "18:30",
    duration: "3 hours",
    location: "TechHub Coworking Space",
    image: codingImg,
    rating: 4.7,
    reviews: 30,
    description: "A crash course in modern web development. Build your first interactive website using React. No prior coding experience required, but basic computer skills recommended.",
    instructor: {
      name: "David Kim",
      avatar: "https://i.pravatar.cc/150?u=david",
      bio: "Senior Frontend Engineer at TechCorp."
    },
    spotsLeft: 8,
    tags: ["Career", "Beginner", "Laptop Required"]
  }
];
