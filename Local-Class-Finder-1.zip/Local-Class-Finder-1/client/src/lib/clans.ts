export interface ClanMember {
  id: string;
  name: string;
  role: "Leader" | "Officer" | "Member";
  joinDate: string;
}

export interface KillRecord {
  id: string;
  bossId: string;
  bossName: string;
  region: string;
  killTime: Date;
  participants: string[]; // Member IDs
  reportedBy: string; // Member ID
}

// Mock clan data
export const mockClanMembers: ClanMember[] = [
  { id: "m1", name: "Admin Leader", role: "Leader", joinDate: "2024-01-15" },
  { id: "m2", name: "Officer Warrior", role: "Officer", joinDate: "2024-02-20" },
  { id: "m3", name: "Knight Assassin", role: "Member", joinDate: "2024-03-10" },
  { id: "m4", name: "Mage Wizard", role: "Member", joinDate: "2024-03-15" },
  { id: "m5", name: "Ranger Archer", role: "Member", joinDate: "2024-04-01" },
  { id: "m6", name: "Paladin Holy", role: "Member", joinDate: "2024-04-05" },
];

export const mockKillRecords: KillRecord[] = [
  {
    id: "k1",
    bossId: "gludio-1",
    bossName: "Tromba",
    region: "Gludio",
    killTime: new Date(Date.now() - 3 * 60 * 60 * 1000),
    participants: ["m1", "m2", "m3"],
    reportedBy: "m1"
  }
];
