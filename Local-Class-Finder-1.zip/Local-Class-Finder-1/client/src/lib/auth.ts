export type UserRole = "Admin" | "Leader" | "Officer";

export interface AuthUser {
  id: string;
  username: string;
  role: UserRole;
  clanId: string;
  clanName?: string;
}

// Mock authentication - setiap user terhubung ke specific clan
export const mockCredentials: Record<string, { password: string; role: UserRole; clanId: string; clanName: string }> = {
  // Dragon Slayers clan
  "admin": { password: "admin123", role: "Admin", clanId: "clan_001", clanName: "Dragon Slayers" },
  "ketua": { password: "ketua123", role: "Leader", clanId: "clan_001", clanName: "Dragon Slayers" },
  "officer": { password: "officer123", role: "Officer", clanId: "clan_001", clanName: "Dragon Slayers" },
  
  // Phoenix Rising clan
  "phoenix_leader": { password: "phoenix123", role: "Leader", clanId: "clan_002", clanName: "Phoenix Rising" },
  "phoenix_officer": { password: "phoenix123", role: "Officer", clanId: "clan_002", clanName: "Phoenix Rising" },
  
  // Shadow Hunters clan
  "shadow_leader": { password: "shadow123", role: "Leader", clanId: "clan_003", clanName: "Shadow Hunters" },
  "shadow_officer1": { password: "shadow123", role: "Officer", clanId: "clan_003", clanName: "Shadow Hunters" },
  
  // Holy Knights clan
  "holy_leader": { password: "holy123", role: "Leader", clanId: "clan_004", clanName: "Holy Knights" },
  "holy_officer": { password: "holy123", role: "Officer", clanId: "clan_004", clanName: "Holy Knights" }
};

// Mock current user
let currentUser: AuthUser | null = null;

export function login(username: string, password: string): AuthUser | null {
  const cred = mockCredentials[username.toLowerCase()];
  if (cred && cred.password === password) {
    currentUser = {
      id: `user_${Date.now()}`,
      username,
      role: cred.role,
      clanId: cred.clanId,
      clanName: cred.clanName
    };
    localStorage.setItem("auth_user", JSON.stringify(currentUser));
    return currentUser;
  }
  return null;
}

export function logout(): void {
  currentUser = null;
  localStorage.removeItem("auth_user");
}

export function getCurrentUser(): AuthUser | null {
  if (currentUser) return currentUser;
  
  const stored = localStorage.getItem("auth_user");
  if (stored) {
    currentUser = JSON.parse(stored);
    return currentUser;
  }
  return null;
}

export function isAuthenticated(): boolean {
  return getCurrentUser() !== null;
}
