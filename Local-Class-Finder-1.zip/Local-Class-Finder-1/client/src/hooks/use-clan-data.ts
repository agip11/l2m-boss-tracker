import { useState, useEffect, useCallback } from "react";
import { ClanMember } from "../lib/clans";

export interface KillRecord {
  id: string;
  bossName: string;
  region: string;
  killTime: Date;
  participants: string[];
  reportedBy: string;
}

export interface Clan {
  id: string;
  name: string;
  leader: string;
  members: ClanMember[];
  killRecords: KillRecord[];
  createdDate: string;
}

interface DbClan {
  id: string;
  name: string;
  leader: string;
  createdDate: string;
}

interface DbClanMember {
  id: string;
  clanId: string;
  name: string;
  role: string;
  joinDate: string;
}

interface DbKillRecord {
  id: string;
  clanId: string;
  bossName: string;
  region: string;
  killTime: number;
  participants: string;
  reportedBy: string;
}

const defaultClans: Clan[] = [
  {
    id: "clan_001",
    name: "Dragon Slayers",
    leader: "Admin",
    createdDate: "2024-01-15",
    members: [
      { id: "m1", name: "Admin Leader", role: "Leader", joinDate: "2024-01-15" },
      { id: "m2", name: "Officer Warrior", role: "Officer", joinDate: "2024-02-20" },
      { id: "m3", name: "Knight Assassin", role: "Member", joinDate: "2024-03-10" },
    ],
    killRecords: []
  },
  {
    id: "clan_002",
    name: "Phoenix Rising",
    leader: "Phoenix Leader",
    createdDate: "2024-02-10",
    members: [
      { id: "m7", name: "Phoenix Leader", role: "Leader", joinDate: "2024-02-10" },
      { id: "m8", name: "Phoenix Officer", role: "Officer", joinDate: "2024-02-15" },
    ],
    killRecords: []
  },
  {
    id: "clan_003",
    name: "Shadow Hunters",
    leader: "Shadow Master",
    createdDate: "2024-03-05",
    members: [
      { id: "m12", name: "Shadow Master", role: "Leader", joinDate: "2024-03-05" },
      { id: "m13", name: "Shadow Officer", role: "Officer", joinDate: "2024-03-10" },
    ],
    killRecords: []
  },
  {
    id: "clan_004",
    name: "Holy Knights",
    leader: "Holy Lord",
    createdDate: "2024-04-01",
    members: [
      { id: "m18", name: "Holy Lord", role: "Leader", joinDate: "2024-04-01" },
      { id: "m19", name: "Holy Officer", role: "Officer", joinDate: "2024-04-05" },
    ],
    killRecords: []
  }
];

const INITIALIZED_KEY = "clan_data_initialized_v4";

async function seedDefaultClans(): Promise<void> {
  console.log("[CLAN-INIT] Seeding default clans...");
  for (const clan of defaultClans) {
    await fetch("/api/clans", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: clan.id,
        name: clan.name,
        leader: clan.leader,
        createdDate: clan.createdDate
      })
    });
    
    for (const member of clan.members) {
      await fetch(`/api/clans/${clan.id}/members`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: member.id,
          name: member.name,
          role: member.role,
          joinDate: member.joinDate
        })
      });
    }
  }
  localStorage.setItem(INITIALIZED_KEY, "true");
}

async function fetchClansFromAPI(): Promise<Clan[]> {
  const response = await fetch("/api/clans");
  const dbClans: DbClan[] = await response.json();
  
  const clans: Clan[] = [];
  
  for (const dbClan of dbClans) {
    const membersRes = await fetch(`/api/clans/${dbClan.id}/members`);
    const dbMembers: DbClanMember[] = await membersRes.json();
    
    const killsRes = await fetch(`/api/clans/${dbClan.id}/kills`);
    const dbKills: DbKillRecord[] = await killsRes.json();
    
    clans.push({
      id: dbClan.id,
      name: dbClan.name,
      leader: dbClan.leader,
      createdDate: dbClan.createdDate,
      members: dbMembers.map(m => ({
        id: m.id,
        name: m.name,
        role: m.role as "Leader" | "Officer" | "Member",
        joinDate: m.joinDate
      })),
      killRecords: dbKills.map(k => ({
        id: k.id,
        bossName: k.bossName,
        region: k.region,
        killTime: new Date(k.killTime),
        participants: JSON.parse(k.participants),
        reportedBy: k.reportedBy
      }))
    });
  }
  
  return clans;
}

export function useClanData() {
  const [clans, setClans] = useState<Clan[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadClans = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      const hasInitialized = localStorage.getItem(INITIALIZED_KEY) === "true";
      let fetchedClans = await fetchClansFromAPI();
      
      if (fetchedClans.length === 0 && !hasInitialized) {
        await seedDefaultClans();
        fetchedClans = await fetchClansFromAPI();
      }
      
      console.log(`[CLAN-DATA] Loaded ${fetchedClans.length} clans from database`);
      setClans(fetchedClans);
    } catch (err) {
      console.error("[CLAN-DATA] Error loading clans:", err);
      setError(err instanceof Error ? err.message : "Failed to load clans");
      setClans(defaultClans);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadClans();
  }, [loadClans]);

  const getClanById = useCallback((clanId: string): Clan | undefined => {
    return clans.find(c => c.id === clanId);
  }, [clans]);

  const getClanMembers = useCallback((clanId: string): ClanMember[] => {
    const clan = getClanById(clanId);
    return clan ? clan.members : [];
  }, [getClanById]);

  const getClanKillRecords = useCallback((clanId: string): KillRecord[] => {
    const clan = getClanById(clanId);
    return clan ? clan.killRecords : [];
  }, [getClanById]);

  const getClanDisplayName = useCallback((clanId: string): string => {
    const clan = getClanById(clanId);
    return clan ? clan.name : "Unknown Clan";
  }, [getClanById]);

  const addClanMember = useCallback(async (clanId: string, member: ClanMember) => {
    try {
      await fetch(`/api/clans/${clanId}/members`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: member.id,
          name: member.name,
          role: member.role,
          joinDate: member.joinDate
        })
      });
      
      setClans(prev => prev.map(clan => 
        clan.id === clanId 
          ? { ...clan, members: [...clan.members, member] }
          : clan
      ));
    } catch (err) {
      console.error("Failed to add member:", err);
    }
  }, []);

  const deleteClanMember = useCallback(async (clanId: string, memberId: string) => {
    try {
      await fetch(`/api/clans/${clanId}/members/${memberId}`, {
        method: "DELETE"
      });
      
      setClans(prev => prev.map(clan => 
        clan.id === clanId 
          ? { ...clan, members: clan.members.filter(m => m.id !== memberId) }
          : clan
      ));
    } catch (err) {
      console.error("Failed to delete member:", err);
    }
  }, []);

  const updateClanName = useCallback(async (clanId: string, newName: string) => {
    try {
      await fetch(`/api/clans/${clanId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newName })
      });
      
      setClans(prev => prev.map(clan => 
        clan.id === clanId 
          ? { ...clan, name: newName }
          : clan
      ));
    } catch (err) {
      console.error("Failed to update clan name:", err);
    }
  }, []);

  const addKillRecord = useCallback(async (clanId: string, record: KillRecord, memberNames?: string[]) => {
    try {
      await fetch(`/api/clans/${clanId}/kills`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: record.id,
          bossName: record.bossName,
          region: record.region,
          killTime: record.killTime.getTime(),
          participants: JSON.stringify(record.participants),
          reportedBy: record.reportedBy
        })
      });
      
      // Also save attendance (deduplication handled by server)
      if (memberNames && memberNames.length > 0) {
        await fetch(`/api/clans/${clanId}/kills/${record.id}/attendance`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            participants: memberNames,
            bossName: record.bossName,
            killTime: record.killTime.getTime(),
            reportedBy: record.reportedBy
          })
        });
      }
      
      setClans(prev => prev.map(clan => 
        clan.id === clanId 
          ? { ...clan, killRecords: [...clan.killRecords, record] }
          : clan
      ));
    } catch (err) {
      console.error("Failed to add kill record:", err);
    }
  }, []);

  const updateKillRecord = useCallback(async (clanId: string, killId: string, participants: string[], memberNames?: string[], bossName?: string, killTime?: number, reportedByName?: string) => {
    try {
      await fetch(`/api/kills/${killId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ participants: JSON.stringify(participants) })
      });
      
      // Update attendance if member names provided
      if (memberNames && memberNames.length > 0 && bossName && killTime) {
        await fetch(`/api/clans/${clanId}/kills/${killId}/attendance`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            participants: memberNames,
            bossName,
            killTime,
            reportedBy: reportedByName || ""
          })
        });
      }
      
      setClans(prev => prev.map(clan => 
        clan.id === clanId 
          ? { 
              ...clan, 
              killRecords: clan.killRecords.map(k => 
                k.id === killId ? { ...k, participants } : k
              )
            }
          : clan
      ));
    } catch (err) {
      console.error("Failed to update kill record:", err);
    }
  }, []);

  return {
    clans,
    loading,
    error,
    refresh: loadClans,
    getClanById,
    getClanMembers,
    getClanKillRecords,
    getClanDisplayName,
    addClanMember,
    deleteClanMember,
    updateClanName,
    addKillRecord,
    updateKillRecord
  };
}
