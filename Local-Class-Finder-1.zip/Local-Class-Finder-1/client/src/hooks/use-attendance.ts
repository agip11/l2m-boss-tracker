import { useState, useEffect, useCallback } from "react";

export interface AttendanceRecap {
  memberName: string;
  points: number;
  bosses: string[];
}

export interface WeeklyAttendance {
  clanId: string;
  weekNumber: number;
  year: number;
  totalKills: number;
  recap: AttendanceRecap[];
}

function getWeekNumber(date: Date): number {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
}

export function useAttendance(clanId: string) {
  const [weeklyAttendance, setWeeklyAttendance] = useState<WeeklyAttendance | null>(null);
  const [loading, setLoading] = useState(false);
  const [currentWeek, setCurrentWeek] = useState(() => getWeekNumber(new Date()));
  const [currentYear, setCurrentYear] = useState(() => new Date().getFullYear());

  const fetchWeeklyAttendance = useCallback(async (week?: number, year?: number) => {
    const targetWeek = week ?? currentWeek;
    const targetYear = year ?? currentYear;
    
    setLoading(true);
    try {
      const response = await fetch(
        `/api/clans/${clanId}/attendance/weekly?week=${targetWeek}&year=${targetYear}`
      );
      if (response.ok) {
        const data = await response.json();
        setWeeklyAttendance(data);
      }
    } catch (error) {
      console.error("[ATTENDANCE] Error fetching weekly attendance:", error);
    } finally {
      setLoading(false);
    }
  }, [clanId, currentWeek, currentYear]);

  const saveAttendance = async (
    killRecordId: string,
    participants: string[],
    bossName: string,
    killTime: number,
    reportedBy: string
  ) => {
    try {
      const response = await fetch(
        `/api/clans/${clanId}/kills/${killRecordId}/attendance`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            participants,
            bossName,
            killTime,
            reportedBy,
          }),
        }
      );
      
      if (response.ok) {
        await fetchWeeklyAttendance();
        return true;
      }
      return false;
    } catch (error) {
      console.error("[ATTENDANCE] Error saving attendance:", error);
      return false;
    }
  };

  const changeWeek = (week: number, year: number) => {
    setCurrentWeek(week);
    setCurrentYear(year);
  };

  const goToPreviousWeek = () => {
    let newWeek = currentWeek - 1;
    let newYear = currentYear;
    if (newWeek < 1) {
      newWeek = 52;
      newYear--;
    }
    changeWeek(newWeek, newYear);
  };

  const goToNextWeek = () => {
    let newWeek = currentWeek + 1;
    let newYear = currentYear;
    if (newWeek > 52) {
      newWeek = 1;
      newYear++;
    }
    changeWeek(newWeek, newYear);
  };

  const goToCurrentWeek = () => {
    const now = new Date();
    changeWeek(getWeekNumber(now), now.getFullYear());
  };

  useEffect(() => {
    fetchWeeklyAttendance(currentWeek, currentYear);
  }, [clanId, currentWeek, currentYear]);

  return {
    weeklyAttendance,
    loading,
    currentWeek,
    currentYear,
    fetchWeeklyAttendance,
    saveAttendance,
    goToPreviousWeek,
    goToNextWeek,
    goToCurrentWeek,
  };
}
