import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { Navbar } from "@/components/Navbar";
import { BossTimerCard } from "@/components/BossTimerCard";
import { AdminLogin } from "@/pages/AdminLogin";
import { ClanDashboard } from "@/pages/ClanDashboard";
import { DiscordSettings } from "@/pages/DiscordSettings";
import { AdminSettings } from "@/pages/AdminSettings";
import { AccessCode } from "@/pages/AccessCode";
import { BOSS_DATA } from "@/lib/l2m-data";
import { mockClanMembers } from "@/lib/clans";
import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Search, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { getCurrentUser } from "@/lib/auth";
import { useClanData } from "@/hooks/use-clan-data";
import { getNextSpawnTime } from "@/lib/boss-state";

function Dashboard() {
  const [selectedRegion, setSelectedRegion] = useState<string>("ALL");
  const [searchQuery, setSearchQuery] = useState("");
  const [refreshTrigger, setRefreshTrigger] = useState(0); // Trigger re-sort
  const user = getCurrentUser();
  const { getClanMembers, loading } = useClanData();

  const regions = ["ALL", "Gludio", "Dion", "Giran", "Oren", "Aden"];

  // Get clan members berdasarkan user yang login (termasuk added members)
  const clanMembers = user ? getClanMembers(user.clanId) : mockClanMembers;

  // Check if user can register kill (Admin, Leader/Ketua, or Officer)
  const canRegisterKill = Boolean(user && (user.role === "Admin" || user.role === "Leader" || user.role === "Officer"));

  // Re-calculate top 5 every second for dynamic updates (auto-spawn and real-time sorting)
  useEffect(() => {
    const timer = setInterval(() => {
      setRefreshTrigger(prev => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Sort bosses by next spawn time, then apply filters
  const sortedBosses = [...BOSS_DATA].sort((a, b) => {
    const nextSpawnA = getNextSpawnTime(a.id, a.respawnTimeHours);
    const nextSpawnB = getNextSpawnTime(b.id, b.respawnTimeHours);
    
    // Bosses with null nextSpawn (alive) go to the end
    if (!nextSpawnA && !nextSpawnB) return 0;
    if (!nextSpawnA) return 1;
    if (!nextSpawnB) return -1;
    
    // Both are guaranteed to be Date objects here, but add safety check
    const timeA = nextSpawnA instanceof Date ? nextSpawnA.getTime() : Infinity;
    const timeB = nextSpawnB instanceof Date ? nextSpawnB.getTime() : Infinity;
    return timeA - timeB;
  });

  const filteredBosses = sortedBosses.filter((boss) => {
    const matchesRegion = selectedRegion === "ALL" || boss.region === selectedRegion;
    const matchesSearch = boss.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesRegion && matchesSearch;
  });

  // Get top 5 bosses for featured section
  const topBosses = filteredBosses.slice(0, 5);
  const remainingBosses = filteredBosses.slice(5);

  const handleStateChange = () => {
    setRefreshTrigger(prev => prev + 1);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header / Filter Bar */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8">
        <div className="flex flex-wrap gap-2">
          {regions.map((region) => (
            <button
              key={region}
              onClick={() => setSelectedRegion(region)}
              className={cn(
                "px-4 py-2 rounded-full text-xs font-bold uppercase tracking-widest transition-all border",
                selectedRegion === region
                  ? "bg-primary text-primary-foreground border-primary shadow-[0_0_15px_rgba(234,179,8,0.4)]"
                  : "bg-card text-muted-foreground border-border hover:border-primary/50 hover:text-foreground"
              )}
            >
              {region}
            </button>
          ))}
        </div>

        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="SEARCH BOSS..." 
            className="pl-9 bg-card border-border focus:border-primary uppercase text-xs font-medium tracking-wide"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {/* Featured Top 5 Section */}
      {topBosses.length > 0 && (
        <div className="mb-12">
          <div className="flex items-center gap-2 mb-4">
            <Clock className="w-5 h-5 text-primary" />
            <h2 className="font-display text-2xl font-bold uppercase tracking-wide text-primary">
              SPAWN IMMINENCE
            </h2>
            <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest ml-auto">
              {topBosses.length} / {filteredBosses.length}
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-4 mb-6 p-4 rounded-lg bg-primary/5 border-2 border-primary/20">
            {topBosses.map((boss) => (
              <BossTimerCard 
                key={boss.id} 
                boss={boss} 
                clanMembers={clanMembers} 
                canRegisterKill={canRegisterKill}
                onStateChange={handleStateChange}
              />
            ))}
          </div>
        </div>
      )}

      {/* Remaining Bosses */}
      {filteredBosses.length > 0 && (
        <div>
          {remainingBosses.length > 0 && (
            <h3 className="font-display text-lg font-bold uppercase tracking-wide text-muted-foreground mb-4">
              Other Bosses
            </h3>
          )}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {remainingBosses.map((boss) => (
              <BossTimerCard 
                key={boss.id} 
                boss={boss} 
                clanMembers={clanMembers} 
                canRegisterKill={canRegisterKill}
                onStateChange={handleStateChange}
              />
            ))}
          </div>
        </div>
      )}

      {filteredBosses.length === 0 && (
        <div className="col-span-full text-center py-20 text-muted-foreground">
          No bosses found matching your criteria.
        </div>
      )}
    </div>
  );
}

function App() {
  const [hasAccess, setHasAccess] = useState<boolean>(() => {
    return localStorage.getItem("tracker_access") === "true";
  });

  useEffect(() => {
    const handleStorageChange = () => {
      setHasAccess(localStorage.getItem("tracker_access") === "true");
    };

    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []);

  // Jika tidak memiliki akses, tampilkan halaman access code
  if (!hasAccess) {
    return (
      <QueryClientProvider client={queryClient}>
        <div className="min-h-screen flex flex-col bg-background selection:bg-primary/30">
          <AccessCode onAccessGranted={() => setHasAccess(true)} />
          <Toaster />
        </div>
      </QueryClientProvider>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen flex flex-col bg-background selection:bg-primary/30">
        <Navbar />
        <main className="flex-1">
          <Switch>
            <Route path="/login" component={AdminLogin} />
            <Route path="/clan-dashboard" component={ClanDashboard} />
            <Route path="/settings" component={AdminSettings} />
            <Route path="/" component={Dashboard} />
            <Route path="/discord" component={DiscordSettings} />
            <Route>404 - Not Found</Route>
          </Switch>
        </main>
        <Toaster />
      </div>
    </QueryClientProvider>
  );
}

export default App;
