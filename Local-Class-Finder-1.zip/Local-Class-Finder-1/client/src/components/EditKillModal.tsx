import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Users } from "lucide-react";
import { ClanMember } from "@/lib/clans";
import { format } from "date-fns";

interface EditKillModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (participantIds: string[]) => void;
  bossName: string;
  region: string;
  killTime: Date;
  currentParticipants: string[];
  availableMembers: ClanMember[];
}

export function EditKillModal({
  isOpen,
  onClose,
  onSave,
  bossName,
  region,
  killTime,
  currentParticipants,
  availableMembers
}: EditKillModalProps) {
  const [selectedParticipants, setSelectedParticipants] = useState<string[]>(currentParticipants);
  const [isSaving, setIsSaving] = useState(false);

  const handleToggle = (memberId: string) => {
    if (selectedParticipants.includes(memberId)) {
      setSelectedParticipants(selectedParticipants.filter(id => id !== memberId));
    } else {
      setSelectedParticipants([...selectedParticipants, memberId]);
    }
  };

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      onSave(selectedParticipants);
      setIsSaving(false);
      onClose();
    }, 500);
  };

  const handleOpenChange = (open: boolean) => {
    if (!open) {
      setSelectedParticipants(currentParticipants);
      onClose();
    }
  };

  const selectedMembers = availableMembers.filter(m => selectedParticipants.includes(m.id));

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[500px] bg-card border-border max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display text-xl uppercase tracking-wide">Edit Kill Participants</DialogTitle>
          <DialogDescription>Ubah member yang berpartisipasi dalam kill ini</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Kill Info */}
          <div className="p-3 rounded-lg bg-background/50 border border-border">
            <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-1">Kill Info</p>
            <div className="space-y-1">
              <p className="text-sm font-bold text-foreground">
                <Badge variant="outline" className="text-[10px] mr-2">{region}</Badge>
                {bossName}
              </p>
              <p className="text-xs text-muted-foreground">
                {format(killTime, "dd/MM/yyyy HH:mm")}
              </p>
            </div>
          </div>

          {/* Selected participants */}
          {selectedMembers.length > 0 && (
            <div className="space-y-2">
              <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
                Selected ({selectedMembers.length})
              </p>
              <div className="flex flex-wrap gap-2 p-2 rounded-lg bg-primary/5 border border-primary/20">
                {selectedMembers.map(member => (
                  <Badge
                    key={member.id}
                    variant="secondary"
                    className="bg-primary/20 text-primary hover:bg-primary/30 cursor-pointer"
                    onClick={() => handleToggle(member.id)}
                  >
                    {member.name} ✕
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Member list */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-primary" />
              <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
                Available Members
              </p>
            </div>
            <div className="max-h-48 overflow-y-auto space-y-2 p-2 rounded-lg border border-border bg-background/50">
              {availableMembers.map(member => (
                <div
                  key={member.id}
                  className="flex items-center space-x-2 p-2 hover:bg-primary/5 rounded cursor-pointer transition-colors"
                >
                  <Checkbox
                    id={`kill_${member.id}`}
                    checked={selectedParticipants.includes(member.id)}
                    onCheckedChange={() => handleToggle(member.id)}
                  />
                  <Label
                    htmlFor={`kill_${member.id}`}
                    className="flex-1 cursor-pointer flex items-center gap-2"
                  >
                    <span className="font-medium text-foreground">{member.name}</span>
                    <Badge variant="outline" className="text-[10px] h-5 border-muted-foreground/30 text-muted-foreground">
                      {member.role}
                    </Badge>
                  </Label>
                </div>
              ))}
            </div>
          </div>
        </div>

        <DialogFooter className="flex gap-2">
          <Button variant="outline" onClick={onClose} disabled={isSaving}>
            Batal
          </Button>
          <Button
            onClick={handleSave}
            className="bg-primary hover:bg-primary/90 text-primary-foreground uppercase font-bold tracking-wider"
            disabled={isSaving}
          >
            {isSaving ? "Menyimpan..." : "Simpan"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
