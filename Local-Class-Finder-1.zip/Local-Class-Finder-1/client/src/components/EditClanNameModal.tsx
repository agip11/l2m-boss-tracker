import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertCircle } from "lucide-react";

interface EditClanNameModalProps {
  isOpen: boolean;
  currentName: string;
  onClose: () => void;
  onSave: (newName: string) => void;
}

export function EditClanNameModal({ isOpen, currentName, onClose, onSave }: EditClanNameModalProps) {
  const [newName, setNewName] = useState(currentName);
  const [error, setError] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = () => {
    setError("");

    if (!newName.trim()) {
      setError("Nama clan tidak boleh kosong!");
      return;
    }

    if (newName.trim() === currentName) {
      onClose();
      return;
    }

    setIsSaving(true);
    setTimeout(() => {
      onSave(newName.trim());
      setIsSaving(false);
      setNewName(currentName);
      onClose();
    }, 500);
  };

  const handleOpenChange = (open: boolean) => {
    if (!open) {
      setNewName(currentName);
      setError("");
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[400px] bg-card border-border">
        <DialogHeader>
          <DialogTitle className="font-display text-xl uppercase tracking-wide">Edit Nama Clan</DialogTitle>
          <DialogDescription>Ubah nama clan yang akan berlaku untuk semua anggota</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label className="uppercase text-xs font-bold tracking-widest text-muted-foreground">
              Nama Clan Baru
            </Label>
            <Input
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="Masukkan nama clan..."
              className="bg-background border-primary/20 focus:border-primary text-base"
              autoFocus
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handleSave();
                }
              }}
            />
          </div>

          {error && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-500 text-sm">
              <AlertCircle className="w-4 h-4 shrink-0" />
              {error}
            </div>
          )}

          <div className="text-xs text-muted-foreground">
            Nama clan akan diubah untuk semua anggota dan dokumentasi.
          </div>
        </div>

        <DialogFooter className="flex gap-2">
          <Button variant="outline" onClick={onClose} disabled={isSaving}>
            Batal
          </Button>
          <Button
            onClick={handleSave}
            className="bg-primary hover:bg-primary/90 text-primary-foreground uppercase font-bold tracking-wider"
            disabled={isSaving || !newName.trim()}
          >
            {isSaving ? "Menyimpan..." : "Simpan"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
