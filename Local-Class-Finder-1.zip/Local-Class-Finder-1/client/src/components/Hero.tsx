import { Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function Hero() {
  return (
    <div className="relative w-full h-[500px] flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center"
        style={{ 
          backgroundImage: 'url("https://images.unsplash.com/photo-1523580494863-6f3031224c94?q=80&w=2070&auto=format&fit=crop")',
        }}
      >
        <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center">
        <h1 className="font-display font-bold text-4xl md:text-6xl text-white mb-6 drop-shadow-sm">
          Master a new skill <br className="hidden md:block" />
          <span className="text-transparent bg-clip-text bg-linear-to-r from-teal-200 to-emerald-200">
            in your neighborhood
          </span>
        </h1>
        <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto mb-10 font-light">
          Join thousands of locals discovering workshops, classes, and experiences happening right around the corner.
        </p>

        {/* Search Bar - Hero Version */}
        <div className="max-w-3xl mx-auto bg-white p-2 rounded-2xl shadow-2xl flex flex-col md:flex-row gap-2 items-center">
          <div className="flex-1 w-full relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input 
              className="w-full pl-12 border-0 shadow-none text-lg h-12 focus-visible:ring-0" 
              placeholder="What do you want to learn?" 
            />
          </div>
          <div className="h-8 w-px bg-border hidden md:block" />
          <div className="w-full md:w-auto">
             <Input 
              className="w-full md:w-48 border-0 shadow-none text-lg h-12 focus-visible:ring-0 text-center md:text-left" 
              placeholder="Zip Code" 
            />
          </div>
          <Button size="lg" className="w-full md:w-auto h-12 px-8 text-lg font-medium bg-accent hover:bg-accent/90 text-white rounded-xl">
            Explore
          </Button>
        </div>
      </div>
    </div>
  );
}
