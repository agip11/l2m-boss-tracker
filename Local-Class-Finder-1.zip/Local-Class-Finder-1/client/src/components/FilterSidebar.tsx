import { Category } from "@/lib/mockData";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";

export function FilterSidebar() {
  const categories: Category[] = [
    "Art & Craft", 
    "Food & Drink", 
    "Health & Wellness", 
    "Technology", 
    "Music", 
    "Outdoors"
  ];

  return (
    <div className="space-y-8">
      <div>
        <h3 className="font-display font-semibold text-lg mb-4">Categories</h3>
        <div className="space-y-3">
          {categories.map((category) => (
            <div key={category} className="flex items-center space-x-2">
              <Checkbox id={category} />
              <Label 
                htmlFor={category} 
                className="text-sm font-normal text-muted-foreground cursor-pointer hover:text-foreground"
              >
                {category}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h3 className="font-display font-semibold text-lg mb-4">Price Range</h3>
        <Slider defaultValue={[50]} max={200} step={1} className="mb-2" />
        <div className="flex justify-between text-sm text-muted-foreground">
          <span>$0</span>
          <span>$200+</span>
        </div>
      </div>

      <div>
        <h3 className="font-display font-semibold text-lg mb-4">Availability</h3>
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Checkbox id="today" />
            <Label htmlFor="today" className="font-normal">Today</Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="weekend" />
            <Label htmlFor="weekend" className="font-normal">This Weekend</Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="next-week" />
            <Label htmlFor="next-week" className="font-normal">Next Week</Label>
          </div>
        </div>
      </div>

      <Button className="w-full" variant="outline">Reset Filters</Button>
    </div>
  );
}
