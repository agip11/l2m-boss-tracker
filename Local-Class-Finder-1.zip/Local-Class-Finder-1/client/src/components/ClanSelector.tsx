import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Sword } from "lucide-react";
import { Clan } from "@/hooks/use-clan-data";

interface ClanSelectorProps {
  selectedClanId: string;
  onSelectClan: (clanId: string) => void;
  clans: Clan[];
}

export function ClanSelector({ selectedClanId, onSelectClan, clans }: ClanSelectorProps) {
  return (
    <Select value={selectedClanId} onValueChange={onSelectClan}>
      <SelectTrigger className="w-56 bg-background border-primary/20 focus:border-primary">
        <div className="flex items-center gap-2">
          <Sword className="w-4 h-4 text-primary" />
          <SelectValue />
        </div>
      </SelectTrigger>
      <SelectContent className="bg-card border-border">
        {clans.map(clan => (
          <SelectItem key={clan.id} value={clan.id}>
            <div className="flex items-center gap-2">
              <span className="font-bold">{clan.name}</span>
              <Badge variant="outline" className="text-[10px]">
                {clan.members.length} members
              </Badge>
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
