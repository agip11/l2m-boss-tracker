import { Link, useLocation } from "wouter";
import { Shield, Users, LogIn, Menu, LogOut, BarChart3, RotateCcw, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { getCurrentUser, logout } from "@/lib/auth";
import { clearAllBossState } from "@/lib/boss-state";
import { useState } from "react";

export function Navbar() {
  const [location, setLocation] = useLocation();
  const user = getCurrentUser();
  const [isResetDialogOpen, setIsResetDialogOpen] = useState(false);
  
  const handleLogout = () => {
    logout();
    setLocation("/");
  };

  const handleResetBosses = async () => {
    try {
      await clearAllBossState();
      setIsResetDialogOpen(false);
      window.location.reload(); // Reload untuk refresh UI
    } catch (error) {
      console.error("Reset failed:", error);
      alert("Reset failed: " + (error instanceof Error ? error.message : "Unknown error"));
      setIsResetDialogOpen(false);
    }
  };

  // Check if user can reset (Admin or Leader)
  const canReset = user && (user.role === "Admin" || user.role === "Leader");

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-border bg-card/80 backdrop-blur-md">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-10 h-10 rounded-lg bg-primary/20 border border-primary flex items-center justify-center text-primary group-hover:scale-105 transition-transform shadow-[0_0_15px_rgba(234,179,8,0.3)]">
            <Shield className="w-6 h-6" />
          </div>
          <div className="flex flex-col">
            <span className="font-display font-bold text-xl tracking-wider text-foreground leading-none">
              L2M <span className="text-primary">TRACKER</span>
            </span>
            <span className="text-[10px] text-muted-foreground font-mono tracking-widest uppercase">
              Clan Boss Manager
            </span>
          </div>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-6">
          <Link href="/" className={`text-sm font-medium tracking-wide uppercase hover:text-primary transition-colors ${location === "/" ? "text-primary" : "text-muted-foreground"}`}>
            Timers
          </Link>
          <Link href="/discord" className={`text-sm font-medium tracking-wide uppercase hover:text-primary transition-colors ${location === "/discord" ? "text-primary" : "text-muted-foreground"}`}>
            Discord Bot
          </Link>
          <div className="h-4 w-px bg-border mx-2" />
          
          {canReset && (
            <AlertDialog open={isResetDialogOpen} onOpenChange={setIsResetDialogOpen}>
              <AlertDialogTrigger asChild>
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="gap-2 border-amber-500/50 text-amber-600 hover:bg-amber-500/10"
                  data-testid="button-reset-bosses"
                >
                  <RotateCcw className="w-4 h-4" />
                  Reset Boss Data
                </Button>
              </AlertDialogTrigger>
            <AlertDialogContent className="bg-card border-border">
              <AlertDialogHeader>
                <AlertDialogTitle className="text-lg font-bold uppercase tracking-wide">Reset All Boss Data?</AlertDialogTitle>
                <AlertDialogDescription className="text-sm text-muted-foreground mt-2">
                  This will clear all kill records and set all bosses to UNTRACKED status. Use this after server maintenance when bosses spawn randomly.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <div className="flex gap-3">
                <AlertDialogCancel className="flex-1">Cancel</AlertDialogCancel>
                <AlertDialogAction 
                  onClick={handleResetBosses}
                  className="flex-1 bg-amber-600 hover:bg-amber-700 text-white"
                  data-testid="button-confirm-reset"
                >
                  Reset All Data
                </AlertDialogAction>
              </div>
            </AlertDialogContent>
          </AlertDialog>
          )}
          
          {user ? (
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 px-3 py-1 rounded-lg bg-primary/10 border border-primary/30">
                <span className="text-sm font-medium text-primary uppercase tracking-wide">{user.username}</span>
                <Badge className="bg-primary/20 text-primary text-[10px] font-bold">
                  {user.role === "Leader" ? "KETUA" : user.role}
                </Badge>
              </div>
              {user.role === "Admin" && (
                <Link href="/settings">
                  <Button size="sm" variant="outline" className="gap-2 border-primary/50 text-primary hover:bg-primary/10">
                    <Settings className="w-4 h-4" />
                    Settings
                  </Button>
                </Link>
              )}
              <Link href="/clan-dashboard">
                <Button size="sm" className="gap-2 bg-primary hover:bg-primary/90 text-primary-foreground">
                  <BarChart3 className="w-4 h-4" />
                  Dashboard
                </Button>
              </Link>
              <Button 
                size="sm" 
                variant="outline" 
                className="gap-2 border-red-500/50 text-red-500 hover:bg-red-500/10"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4" />
                Logout
              </Button>
            </div>
          ) : (
            <Link href="/login">
              <Button variant="outline" size="sm" className="gap-2 border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground">
                <LogIn className="w-4 h-4" />
                Clan Login
              </Button>
            </Link>
          )}
        </div>

        {/* Mobile Menu */}
        <div className="md:hidden">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="w-5 h-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 bg-card border-border">
              <Link href="/">
                <DropdownMenuItem className="cursor-pointer">Boss Timers</DropdownMenuItem>
              </Link>
              <Link href="/discord">
                <DropdownMenuItem className="cursor-pointer">Discord Integration</DropdownMenuItem>
              </Link>
              {canReset && (
                <AlertDialog open={isResetDialogOpen} onOpenChange={setIsResetDialogOpen}>
                  <AlertDialogTrigger asChild>
                    <DropdownMenuItem className="cursor-pointer text-amber-600" onClick={(e) => e.preventDefault()}>
                      Reset Boss Data
                    </DropdownMenuItem>
                  </AlertDialogTrigger>
                <AlertDialogContent className="bg-card border-border">
                  <AlertDialogHeader>
                    <AlertDialogTitle className="text-lg font-bold uppercase tracking-wide">Reset All Boss Data?</AlertDialogTitle>
                    <AlertDialogDescription className="text-sm text-muted-foreground mt-2">
                      This will clear all kill records and set all bosses to UNTRACKED status. Use this after server maintenance.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <div className="flex gap-3">
                    <AlertDialogCancel className="flex-1">Cancel</AlertDialogCancel>
                    <AlertDialogAction 
                      onClick={handleResetBosses}
                      className="flex-1 bg-amber-600 hover:bg-amber-700 text-white"
                    >
                      Reset All Data
                    </AlertDialogAction>
                  </div>
                </AlertDialogContent>
              </AlertDialog>
              )}
              {user ? (
                <>
                  <div className="px-2 py-2 text-xs border-y border-border my-1">
                    <p className="font-bold text-primary">{user.username}</p>
                    <p className="text-muted-foreground">{user.role === "Leader" ? "KETUA" : user.role}</p>
                  </div>
                  {user.role === "Admin" && (
                    <Link href="/settings">
                      <DropdownMenuItem className="cursor-pointer text-primary">⚙️ Admin Settings</DropdownMenuItem>
                    </Link>
                  )}
                  <Link href="/clan-dashboard">
                    <DropdownMenuItem className="cursor-pointer">Dashboard</DropdownMenuItem>
                  </Link>
                  <DropdownMenuItem 
                    className="cursor-pointer text-red-500"
                    onClick={handleLogout}
                  >
                    Logout
                  </DropdownMenuItem>
                </>
              ) : (
                <Link href="/login">
                  <DropdownMenuItem className="cursor-pointer text-primary">Clan Login</DropdownMenuItem>
                </Link>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </nav>
  );
}
