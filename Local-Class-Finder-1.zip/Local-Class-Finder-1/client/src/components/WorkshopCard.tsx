import { Workshop } from "@/lib/mockData";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, MapPin, Star } from "lucide-react";
import { Link } from "wouter";

interface WorkshopCardProps {
  workshop: Workshop;
}

export function WorkshopCard({ workshop }: WorkshopCardProps) {
  return (
    <Link href={`/workshop/${workshop.id}`}>
      <a className="block group h-full">
        <Card className="h-full overflow-hidden border-border/50 bg-card hover:shadow-lg hover:border-primary/20 transition-all duration-300 flex flex-col">
          {/* Image Container */}
          <div className="relative aspect-[4/3] overflow-hidden">
            <img 
              src={workshop.image} 
              alt={workshop.title} 
              className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute top-3 left-3">
              <Badge className="bg-white/90 text-foreground hover:bg-white backdrop-blur-sm shadow-sm font-medium">
                {workshop.category}
              </Badge>
            </div>
            <div className="absolute bottom-3 right-3">
              <Badge variant="secondary" className="font-bold text-primary bg-white/95 backdrop-blur-sm shadow-sm">
                ${workshop.price}
              </Badge>
            </div>
          </div>

          {/* Content */}
          <div className="p-5 flex flex-col flex-1">
            <div className="flex items-center gap-1 text-yellow-500 mb-2">
              <Star className="w-4 h-4 fill-current" />
              <span className="text-sm font-medium text-foreground">{workshop.rating}</span>
              <span className="text-sm text-muted-foreground">({workshop.reviews})</span>
            </div>

            <h3 className="font-display font-semibold text-xl mb-2 line-clamp-2 group-hover:text-primary transition-colors">
              {workshop.title}
            </h3>

            <div className="space-y-2 mt-auto">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Calendar className="w-4 h-4" />
                <span>{workshop.date}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="w-4 h-4" />
                <span>{workshop.time} ({workshop.duration})</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="w-4 h-4" />
                <span className="truncate">{workshop.location}</span>
              </div>
            </div>

            <div className="mt-5 pt-4 border-t border-border flex items-center justify-between">
              <div className="flex items-center gap-2">
                <img 
                  src={workshop.instructor.avatar} 
                  alt={workshop.instructor.name}
                  className="w-8 h-8 rounded-full border border-border" 
                />
                <span className="text-xs font-medium text-muted-foreground">
                  By {workshop.instructor.name}
                </span>
              </div>
              
              <Button size="sm" variant="outline" className="group-hover:bg-primary group-hover:text-white group-hover:border-primary transition-colors">
                Details
              </Button>
            </div>
          </div>
        </Card>
      </a>
    </Link>
  );
}
