import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Boss } from "@/lib/l2m-data";
import { ClanMember } from "@/lib/clans";
import { Clock, Calendar, Users } from "lucide-react";
import { format, parse, startOfDay, isBefore, isAfter, subDays } from "date-fns";
import { ParticipantSelector } from "./ParticipantSelector";

interface KillReportModalProps {
  boss: Boss;
  clanMembers?: ClanMember[];
  isOpen: boolean;
  onClose: () => void;
  onReportKill: (killTime: Date, participants?: string[]) => void;
}

export function KillReportModal({ boss, clanMembers = [], isOpen, onClose, onReportKill }: KillReportModalProps) {
  const [killDate, setKillDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [killTime, setKillTime] = useState(format(new Date(), "HH:mm"));
  const [selectedParticipants, setSelectedParticipants] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<{ date?: string; time?: string }>({});

  const validateDate = (dateValue: string): string | undefined => {
    if (!dateValue || !/^\d{4}-\d{2}-\d{2}$/.test(dateValue)) {
      return "Format tanggal harus YYYY-MM-DD";
    }
    
    try {
      const parsedDate = parse(dateValue, "yyyy-MM-dd", new Date());
      const dateStart = startOfDay(parsedDate);
      const today = startOfDay(new Date());
      
      if (isNaN(dateStart.getTime())) {
        return "Tanggal tidak valid";
      } else if (isAfter(dateStart, today)) {
        return "Tanggal tidak boleh di masa depan";
      } else if (isBefore(dateStart, subDays(today, 30))) {
        return "Tanggal tidak boleh lebih dari 30 hari yang lalu";
      }
    } catch (e) {
      return "Tanggal tidak valid";
    }
    
    return undefined;
  };

  const validateTime = (timeValue: string): string | undefined => {
    if (!timeValue || !/^\d{2}:\d{2}$/.test(timeValue)) {
      return "Format waktu harus HH:mm";
    }
    
    const [hours, minutes] = timeValue.split(":");
    const h = parseInt(hours);
    const m = parseInt(minutes);
    
    if (isNaN(h) || isNaN(m) || h < 0 || h > 23 || m < 0 || m > 59) {
      return "Waktu harus 00:00-23:59";
    }
    
    return undefined;
  };

  const validateInputs = () => {
    const newErrors: { date?: string; time?: string } = {};
    const dateError = validateDate(killDate);
    const timeError = validateTime(killTime);
    
    if (dateError) newErrors.date = dateError;
    if (timeError) newErrors.time = timeError;

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validateInputs()) {
      return;
    }

    try {
      const [year, month, day] = killDate.split("-");
      const [hours, minutes] = killTime.split(":");
      const killDateTime = new Date(
        parseInt(year),
        parseInt(month) - 1,
        parseInt(day),
        parseInt(hours),
        parseInt(minutes)
      );
      
      setIsSubmitting(true);
      setTimeout(() => {
        onReportKill(killDateTime, selectedParticipants);
        setIsSubmitting(false);
        setSelectedParticipants([]);
        setErrors({});
        onClose();
      }, 500);
    } catch (error) {
      console.error("Error parsing kill time:", error);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[550px] bg-card border-border max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display text-xl uppercase tracking-wide">REPORT KILL</DialogTitle>
          <DialogDescription className="text-muted-foreground text-sm">
            <span className="text-primary font-bold">{boss.name}</span> ({boss.region})
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="info" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-background/50">
            <TabsTrigger value="info" className="uppercase text-xs font-bold">Kill Info</TabsTrigger>
            <TabsTrigger value="participants" className="uppercase text-xs font-bold flex items-center gap-2">
              <Users className="w-3 h-3" /> Participants
            </TabsTrigger>
          </TabsList>

          <TabsContent value="info" className="space-y-6 py-4">
            {/* Respawn Info */}
            <div className="p-3 rounded-lg border border-border bg-background/50">
              <p className="text-xs text-muted-foreground uppercase tracking-widest font-bold mb-2">Respawn Time</p>
              <p className="text-2xl font-mono font-bold text-primary">{boss.respawnTimeHours} JAM</p>
            </div>

            {/* Date Input */}
            <div className="space-y-2">
              <Label className="uppercase text-xs font-bold tracking-widest text-muted-foreground flex items-center gap-2">
                <Calendar className="w-4 h-4" /> Kill Date (YYYY-MM-DD)
              </Label>
              <Input 
                type="text"
                placeholder="YYYY-MM-DD"
                value={killDate}
                onChange={(e) => {
                  const val = e.target.value;
                  if (val === "" || /^\d{0,4}(-\d{0,2}(-\d{0,2})?)?$/.test(val)) {
                    setKillDate(val);
                    // Real-time validation
                    const error = validateDate(val);
                    setErrors(prev => ({ ...prev, date: error }));
                  }
                }}
                maxLength={10}
                className={`bg-background text-lg font-mono transition-colors ${
                  errors.date ? "border-red-500/50 focus:border-red-500" : "border-primary/20 focus:border-primary"
                }`}
              />
              {errors.date ? (
                <p className="text-xs text-red-500 font-medium">{errors.date}</p>
              ) : (
                <p className="text-xs text-muted-foreground">Format: 2025-12-15 (Maks 30 hari lalu)</p>
              )}
            </div>

            {/* Time Input */}
            <div className="space-y-2">
              <Label className="uppercase text-xs font-bold tracking-widest text-muted-foreground flex items-center gap-2">
                <Clock className="w-4 h-4" /> Kill Time (HH:mm)
              </Label>
              <Input 
                type="text"
                placeholder="HH:mm"
                value={killTime}
                onChange={(e) => {
                  const val = e.target.value;
                  if (val === "" || /^\d{0,2}(:\d{0,2})?$/.test(val)) {
                    setKillTime(val);
                    // Real-time validation
                    const error = validateTime(val);
                    setErrors(prev => ({ ...prev, time: error }));
                  }
                }}
                maxLength={5}
                className={`bg-background text-lg font-mono transition-colors ${
                  errors.time ? "border-red-500/50 focus:border-red-500" : "border-primary/20 focus:border-primary"
                }`}
              />
              {errors.time ? (
                <p className="text-xs text-red-500 font-medium">{errors.time}</p>
              ) : (
                <p className="text-xs text-muted-foreground">Format: 00-23:00-59 (24 jam)</p>
              )}
            </div>

            {/* Next Spawn Preview */}
            <div className="p-3 rounded-lg border border-border bg-background/50">
              <p className="text-xs text-muted-foreground uppercase tracking-widest font-bold mb-2">Next Spawn Window</p>
              <p className="text-sm text-foreground font-mono">
                {(() => {
                  try {
                    const [year, month, day] = killDate.split("-");
                    const [hours, minutes] = killTime.split(":");
                    
                    const yearNum = parseInt(year);
                    const monthNum = parseInt(month);
                    const dayNum = parseInt(day);
                    const hoursNum = parseInt(hours);
                    const minutesNum = parseInt(minutes);
                    
                    // Validate parsed values
                    if (isNaN(yearNum) || isNaN(monthNum) || isNaN(dayNum) || isNaN(hoursNum) || isNaN(minutesNum)) {
                      return "-";
                    }
                    
                    const killDateTime = new Date(yearNum, monthNum - 1, dayNum, hoursNum, minutesNum);
                    
                    // Check if date is valid
                    if (isNaN(killDateTime.getTime())) {
                      return "-";
                    }
                    
                    const nextSpawn = new Date(killDateTime.getTime() + boss.respawnTimeHours * 60 * 60 * 1000);
                    return format(nextSpawn, "dd/MM/yyyy HH:mm");
                  } catch (e) {
                    return "-";
                  }
                })()}
              </p>
            </div>
          </TabsContent>

          <TabsContent value="participants" className="py-4">
            {clanMembers.length > 0 ? (
              <ParticipantSelector 
                members={clanMembers}
                selectedIds={selectedParticipants}
                onChange={setSelectedParticipants}
              />
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <p>Belum ada data member clan</p>
              </div>
            )}
          </TabsContent>
        </Tabs>

        <DialogFooter className="flex gap-2">
          <Button variant="outline" onClick={onClose} disabled={isSubmitting}>Cancel</Button>
          <Button 
            onClick={handleSubmit} 
            className="bg-primary hover:bg-primary/90 text-primary-foreground uppercase font-bold tracking-wider disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={isSubmitting || Object.values(errors).some(error => error)}
          >
            {isSubmitting ? "Reporting..." : "Report Kill"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
