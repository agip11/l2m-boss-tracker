import { ClanMember } from "@/lib/clans";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Users } from "lucide-react";

interface ParticipantSelectorProps {
  members: ClanMember[];
  selectedIds: string[];
  onChange: (selectedIds: string[]) => void;
  clanName?: string;
}

export function ParticipantSelector({ members, selectedIds, onChange, clanName = "" }: ParticipantSelectorProps) {

  const handleToggle = (memberId: string) => {
    if (selectedIds.includes(memberId)) {
      onChange(selectedIds.filter(id => id !== memberId));
    } else {
      onChange([...selectedIds, memberId]);
    }
  };

  const selectedMembers = members.filter(m => selectedIds.includes(m.id));

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Users className="w-4 h-4 text-primary" />
        <Label className="uppercase text-xs font-bold tracking-widest text-muted-foreground">
          PARTICIPANTS ({selectedIds.length})
        </Label>
        {clanName && (
          <Badge variant="outline" className="ml-2 text-[10px] text-primary border-primary/50">
            {clanName}
          </Badge>
        )}
      </div>

      {/* Selected members display */}
      {selectedMembers.length > 0 && (
        <div className="flex flex-wrap gap-2 p-2 rounded-lg bg-background/50 border border-border">
          {selectedMembers.map(member => (
            <Badge 
              key={member.id}
              variant="secondary"
              className="bg-primary/20 text-primary hover:bg-primary/30 cursor-pointer"
              onClick={() => handleToggle(member.id)}
            >
              {member.name} ✕
            </Badge>
          ))}
        </div>
      )}

      {/* Member list */}
      <div className="max-h-48 overflow-y-auto space-y-2 p-2 rounded-lg border border-border bg-background/50">
        {members.length > 0 ? (
          members.map(member => (
            <div key={member.id} className="flex items-center space-x-2 p-2 hover:bg-primary/5 rounded cursor-pointer transition-colors">
              <Checkbox 
                id={member.id}
                checked={selectedIds.includes(member.id)}
                onCheckedChange={() => handleToggle(member.id)}
              />
              <Label 
                htmlFor={member.id}
                className="flex-1 cursor-pointer flex items-center gap-2"
              >
                <span className="font-medium text-foreground">{member.name}</span>
                <Badge variant="outline" className="text-[10px] h-5 border-muted-foreground/30 text-muted-foreground">
                  {member.role}
                </Badge>
              </Label>
            </div>
          ))
        ) : (
          <div className="text-center py-4 text-muted-foreground text-sm">
            Tidak ada member tersedia
          </div>
        )}
      </div>
    </div>
  );
}
