import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ClanMember } from "@/lib/clans";

interface AddMemberModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddMember: (name: string, role: "Leader" | "Officer" | "Member") => void;
}

export function AddMemberModal({ isOpen, onClose, onAddMember }: AddMemberModalProps) {
  const [name, setName] = useState("");
  const [role, setRole] = useState<"Leader" | "Officer" | "Member">("Member");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = () => {
    if (!name.trim()) return;
    
    setIsSubmitting(true);
    setTimeout(() => {
      onAddMember(name, role);
      setName("");
      setRole("Member");
      setIsSubmitting(false);
      onClose();
    }, 300);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[400px] bg-card border-border">
        <DialogHeader>
          <DialogTitle className="font-display text-xl uppercase tracking-wide">TAMBAH MEMBER</DialogTitle>
          <DialogDescription>Tambahkan anggota baru ke clan Anda</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label className="uppercase text-xs font-bold tracking-widest text-muted-foreground">Nama Member</Label>
            <Input 
              placeholder="Masukkan nama member..." 
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="bg-background border-primary/20 focus:border-primary"
            />
          </div>

          <div className="space-y-2">
            <Label className="uppercase text-xs font-bold tracking-widest text-muted-foreground">Role</Label>
            <Select value={role} onValueChange={(v) => setRole(v as "Leader" | "Officer" | "Member")}>
              <SelectTrigger className="bg-background border-primary/20 focus:border-primary">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-card border-border">
                <SelectItem value="Member">Member</SelectItem>
                <SelectItem value="Officer">Officer</SelectItem>
                <SelectItem value="Leader">Leader</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter className="flex gap-2">
          <Button variant="outline" onClick={onClose}>Batal</Button>
          <Button 
            onClick={handleSubmit} 
            className="bg-primary hover:bg-primary/90 text-primary-foreground uppercase font-bold tracking-wider"
            disabled={isSubmitting || !name.trim()}
          >
            {isSubmitting ? "Menambah..." : "Tambah Member"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
