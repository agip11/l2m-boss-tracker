import { useState, useEffect, useRef } from "react";
import { Boss } from "@/lib/l2m-data";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Skull, AlertCircle, Volume2 } from "lucide-react";
import { format, differenceInSeconds } from "date-fns";
import { cn } from "@/lib/utils";
import { KillReportModal } from "./KillReportModal";
import { playSpawnNotification, playAudioAlert, shouldPlayNotification } from "@/lib/notifications";
import { getNextSpawnTime, setLastKilledTime } from "@/lib/boss-state";

import { ClanMember } from "@/lib/clans";

interface BossTimerCardProps {
  boss: Boss;
  clanMembers?: ClanMember[];
  canRegisterKill?: boolean;
  onStateChange?: () => void;
}

export function BossTimerCard({ boss, clanMembers = [], canRegisterKill = false, onStateChange }: BossTimerCardProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [, setRefresh] = useState(0);
  const notificationTriggeredRef = useRef<Set<number>>(new Set());
  const lastNextSpawnRef = useRef<Date | null>(null);

  // Force check auto-spawn every second
  useEffect(() => {
    const timer = setInterval(() => {
      setRefresh(prev => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const nextSpawn = getNextSpawnTime(boss.id, boss.respawnTimeHours);

  // Detect auto-spawn: when nextSpawn changes unexpectedly, notify parent to resort
  useEffect(() => {
    if (nextSpawn && lastNextSpawnRef.current && nextSpawn.getTime() !== lastNextSpawnRef.current.getTime()) {
      // nextSpawn changed - this could be auto-spawn, notify parent
      onStateChange?.();
    }
    lastNextSpawnRef.current = nextSpawn ? new Date(nextSpawn) : null;
  }, [nextSpawn, onStateChange]);

  let timeLeft = "READY";
  let status: "ALIVE" | "DEAD" = "ALIVE";

  if (nextSpawn) {
    const now = new Date();
    const diff = differenceInSeconds(nextSpawn, now);

    if (diff <= 0) {
      status = "ALIVE";
      timeLeft = "READY";
      
      if (soundEnabled && shouldPlayNotification(boss.id, 0)) {
        playAudioAlert();
        playSpawnNotification(boss.name, 0);
      }
    } else {
      status = "DEAD";
      const hours = Math.floor(diff / 3600);
      const minutes = Math.floor((diff % 3600) / 60);
      const seconds = diff % 60;
      timeLeft = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;

      if (soundEnabled) {
        const notificationTimes = [30, 15, 10, 5];
        
        for (const notifTime of notificationTimes) {
          const notifSeconds = notifTime * 60;
          // Check if diff is within the notification window (next 2 seconds) and not already triggered
          if (diff <= notifSeconds && diff > notifSeconds - 2 && !notificationTriggeredRef.current.has(notifTime)) {
            notificationTriggeredRef.current.add(notifTime);
            playAudioAlert();
            playSpawnNotification(boss.name, notifTime);
          }
        }
      }
    }
  } else {
    notificationTriggeredRef.current.clear();
  }

  const handleKill = () => {
    setIsModalOpen(true);
  };

  const handleReportKill = async (killTime: Date, participants?: string[]) => {
    // Save using boss-state (now syncs to database)
    setLastKilledTime(boss.id, killTime);
    
    // Send kill report to backend (which will notify Discord)
    try {
      await fetch("/api/kills/report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          bossName: boss.name,
          region: boss.region,
          killTime: killTime.toISOString(),
          respawnTimeHours: boss.respawnTimeHours,
          participants: participants || [],
          guildId: "default-clan",
          webhookUrl: localStorage.getItem("discord_webhook_url") || "",
        }),
      });
    } catch (error) {
      console.error("Failed to report kill:", error);
    }

    // Notify parent of state change for top 5 re-calculation
    onStateChange?.();
  };

  return (
    <>
      <Card className={cn(
        "relative overflow-hidden border-l-4 transition-all hover:shadow-lg hover:shadow-primary/5 group",
        status === "ALIVE" ? "border-l-green-500 bg-green-500/5" : "border-l-red-500 bg-card"
      )}>
        {/* Background decoration */}
        <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
          <Skull className="w-24 h-24" />
        </div>

        <div className="p-4 flex flex-col h-full justify-between relative z-10">
        <div className="flex justify-between items-start mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Badge variant="outline" className="text-[10px] h-5 border-primary/30 text-primary uppercase tracking-wider">
                {boss.region}
              </Badge>
              {boss.spawnChance < 100 && (
                <Badge variant="secondary" className="text-[10px] h-5 bg-muted text-muted-foreground">
                  {boss.spawnChance}% Chance
                </Badge>
              )}
            </div>
            <h3 className="font-display font-bold text-xl text-foreground tracking-wide uppercase">
              {boss.name}
            </h3>
            <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
              <Clock className="w-3 h-3" />
              Respawn: {boss.respawnTimeHours}h
            </p>
          </div>
          
          <div 
            className={cn(
              "text-2xl font-mono font-bold tracking-widest tabular-nums drop-shadow-md",
              status === "ALIVE" ? "text-green-400" : "text-red-400"
            )}
            data-testid={`timer-${boss.id}`}
          >
            {timeLeft}
          </div>
        </div>

        <div className="flex items-center justify-between mt-2 pt-3 border-t border-border/50">
          <div className="text-xs text-muted-foreground">
            {nextSpawn ? (
              <span>Next: <span className="text-foreground font-medium">{format(nextSpawn, "HH:mm")}</span></span>
            ) : (
              <span className="flex items-center gap-1 text-green-500 font-medium">
                <AlertCircle className="w-3 h-3" /> Spawnable
              </span>
            )}
          </div>
          
          <div className="flex items-center gap-2">
            {status === "DEAD" && (
              <Button 
                size="sm"
                variant="ghost"
                className={cn(
                  "h-6 w-6 p-0",
                  soundEnabled ? "text-primary" : "text-muted-foreground"
                )}
                onClick={() => setSoundEnabled(!soundEnabled)}
                title={soundEnabled ? "Disable notifications" : "Enable notifications"}
                data-testid="button-toggle-sound"
              >
                <Volume2 className="w-3 h-3" />
              </Button>
            )}

            {canRegisterKill ? (
              <Button 
                size="sm" 
                variant={status === "ALIVE" ? "default" : "secondary"}
                className={cn(
                  "uppercase font-bold tracking-wider text-xs h-8",
                  status === "ALIVE" && "bg-red-600 hover:bg-red-700 text-white animate-pulse"
                )}
                onClick={handleKill}
                data-testid="button-register-kill"
              >
                {status === "ALIVE" ? "Register Kill" : "Killed"}
              </Button>
            ) : (
              <div className="text-xs text-muted-foreground">
                {status === "ALIVE" ? "View Only" : "Killed"}
              </div>
            )}
          </div>
        </div>
      </div>
    </Card>

    <KillReportModal 
      boss={boss}
      clanMembers={clanMembers}
      isOpen={isModalOpen}
      onClose={() => setIsModalOpen(false)}
      onReportKill={handleReportKill}
    />
    </>
  );
}
