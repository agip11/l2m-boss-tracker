import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Workshop } from "@/lib/mockData";
import { Calendar, Clock, CreditCard, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface BookingModalProps {
  workshop: Workshop;
  isOpen: boolean;
  onClose: () => void;
}

export function BookingModal({ workshop, isOpen, onClose }: BookingModalProps) {
  const [step, setStep] = useState(1);
  const { toast } = useToast();

  const handleBook = () => {
    setStep(2);
    // Simulate API call
    setTimeout(() => {
      setStep(3);
      toast({
        title: "Booking Confirmed!",
        description: `You're all set for ${workshop.title}`,
      });
    }, 1500);
  };

  const handleClose = () => {
    setStep(1);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px]">
        {step === 1 && (
          <>
            <DialogHeader>
              <DialogTitle className="font-display text-2xl">Confirm Booking</DialogTitle>
              <DialogDescription>
                Review your details before payment.
              </DialogDescription>
            </DialogHeader>

            <div className="py-4 space-y-4">
              <div className="flex gap-4 p-4 bg-muted/30 rounded-xl border border-border">
                <img src={workshop.image} alt={workshop.title} className="w-20 h-20 object-cover rounded-lg" />
                <div>
                  <h4 className="font-semibold text-foreground line-clamp-1">{workshop.title}</h4>
                  <div className="text-sm text-muted-foreground mt-1 flex items-center gap-2">
                    <Calendar className="w-3 h-3" /> {workshop.date}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1 flex items-center gap-2">
                    <Clock className="w-3 h-3" /> {workshop.time}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Full Name</Label>
                  <Input placeholder="John Doe" />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input placeholder="john@example.com" />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Card Information</Label>
                <div className="relative">
                  <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input className="pl-9" placeholder="0000 0000 0000 0000" />
                </div>
              </div>

              <div className="flex justify-between items-center pt-2 border-t">
                <span className="font-medium">Total</span>
                <span className="font-bold text-xl text-primary">${workshop.price}</span>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={handleClose}>Cancel</Button>
              <Button onClick={handleBook} className="bg-accent hover:bg-accent/90 text-white">Pay & Book</Button>
            </DialogFooter>
          </>
        )}

        {step === 2 && (
          <div className="py-12 flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mb-4" />
            <h3 className="font-display text-xl font-medium">Processing Payment...</h3>
            <p className="text-muted-foreground">Please do not close this window.</p>
          </div>
        )}

        {step === 3 && (
          <div className="py-8 flex flex-col items-center justify-center text-center space-y-4">
            <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-2">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="font-display text-2xl font-bold text-foreground">Booking Confirmed!</h3>
            <p className="text-muted-foreground max-w-xs mx-auto">
              You've successfully booked <strong>{workshop.title}</strong>. A confirmation email has been sent to you.
            </p>
            <Button onClick={handleClose} className="w-full mt-4">Done</Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
