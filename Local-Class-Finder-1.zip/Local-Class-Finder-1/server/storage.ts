import { type User, type InsertUser, type DiscordConfig, type InsertDiscordConfig, type BossStateRow, type InsertBossState, type Clan, type InsertClan, type ClanMember, type InsertClanMember, type KillRecord, type InsertKillRecord, type BossAttendance, type InsertBossAttendance, users, discordConfig, bossState, clans, clanMembers, killRecords, bossAttendance } from "@shared/schema";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { eq, and, sql } from "drizzle-orm";

const connectionString = process.env.DATABASE_URL!;
const client = postgres(connectionString);

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getDiscordConfig(guildId: string): Promise<DiscordConfig | undefined>;
  saveDiscordConfig(config: InsertDiscordConfig): Promise<DiscordConfig>;
  updateDiscordConfig(guildId: string, config: Partial<InsertDiscordConfig>): Promise<DiscordConfig | undefined>;
  getBossState(bossId: string): Promise<BossStateRow | undefined>;
  saveBossState(state: InsertBossState): Promise<BossStateRow>;
  updateBossState(bossId: string, state: Partial<InsertBossState>): Promise<BossStateRow | undefined>;
  getAllClans(): Promise<Clan[]>;
  getClan(id: string): Promise<Clan | undefined>;
  saveClan(clan: InsertClan): Promise<Clan>;
  updateClan(id: string, updates: Partial<InsertClan>): Promise<Clan | undefined>;
  getClanMembers(clanId: string): Promise<ClanMember[]>;
  saveClanMember(member: InsertClanMember): Promise<ClanMember>;
  deleteClanMember(id: string): Promise<void>;
  getClanKillRecords(clanId: string): Promise<KillRecord[]>;
  saveKillRecord(record: InsertKillRecord): Promise<KillRecord>;
  updateKillRecord(id: string, updates: Partial<InsertKillRecord>): Promise<KillRecord | undefined>;
  saveBossAttendance(attendance: InsertBossAttendance): Promise<BossAttendance>;
  getBossAttendanceByKillRecord(killRecordId: string): Promise<BossAttendance[]>;
  getClanWeeklyAttendance(clanId: string, weekNumber: number, year: number): Promise<BossAttendance[]>;
  getMemberWeeklyAttendance(clanId: string, memberName: string, weekNumber: number, year: number): Promise<BossAttendance[]>;
  deleteBossAttendanceByKillRecord(killRecordId: string): Promise<void>;
}

class DrizzleStorage implements IStorage {
  private db: ReturnType<typeof drizzle>;

  constructor() {
    this.db = drizzle(client);
  }

  async getUser(id: string): Promise<User | undefined> {
    const result = await this.db
      .select()
      .from(users)
      .where(eq(users.id, id))
      .limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await this.db
      .select()
      .from(users)
      .where(eq(users.username, username))
      .limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await this.db
      .insert(users)
      .values(insertUser)
      .returning();
    return result[0];
  }

  async getDiscordConfig(guildId: string): Promise<DiscordConfig | undefined> {
    const result = await this.db
      .select()
      .from(discordConfig)
      .where(eq(discordConfig.guildId, guildId))
      .limit(1);
    return result[0];
  }

  async saveDiscordConfig(config: InsertDiscordConfig): Promise<DiscordConfig> {
    const result = await this.db
      .insert(discordConfig)
      .values(config)
      .returning();
    return result[0];
  }

  async updateDiscordConfig(
    guildId: string,
    updates: Partial<InsertDiscordConfig>,
  ): Promise<DiscordConfig | undefined> {
    const result = await this.db
      .update(discordConfig)
      .set(updates)
      .where(eq(discordConfig.guildId, guildId))
      .returning();
    return result[0];
  }

  async getBossState(bossId: string): Promise<BossStateRow | undefined> {
    const result = await this.db
      .select()
      .from(bossState)
      .where(eq(bossState.bossId, bossId))
      .limit(1);
    return result[0];
  }

  async saveBossState(state: InsertBossState): Promise<BossStateRow> {
    const existing = await this.getBossState(state.bossId);
    if (existing) {
      return await this.updateBossState(state.bossId, state) as BossStateRow;
    }
    const result = await this.db
      .insert(bossState)
      .values(state)
      .returning();
    return result[0];
  }

  async updateBossState(
    bossId: string,
    updates: Partial<InsertBossState>,
  ): Promise<BossStateRow | undefined> {
    const result = await this.db
      .update(bossState)
      .set(updates)
      .where(eq(bossState.bossId, bossId))
      .returning();
    return result[0];
  }

  async getAllClans(): Promise<Clan[]> {
    return await this.db.select().from(clans);
  }

  async getClan(id: string): Promise<Clan | undefined> {
    const result = await this.db
      .select()
      .from(clans)
      .where(eq(clans.id, id))
      .limit(1);
    return result[0];
  }

  async saveClan(clan: InsertClan): Promise<Clan> {
    const existing = await this.getClan(clan.id);
    if (existing) {
      return await this.updateClan(clan.id, clan) as Clan;
    }
    const result = await this.db
      .insert(clans)
      .values(clan)
      .returning();
    return result[0];
  }

  async updateClan(id: string, updates: Partial<InsertClan>): Promise<Clan | undefined> {
    const result = await this.db
      .update(clans)
      .set(updates)
      .where(eq(clans.id, id))
      .returning();
    return result[0];
  }

  async getClanMembers(clanId: string): Promise<ClanMember[]> {
    return await this.db
      .select()
      .from(clanMembers)
      .where(eq(clanMembers.clanId, clanId));
  }

  async saveClanMember(member: InsertClanMember): Promise<ClanMember> {
    const result = await this.db
      .insert(clanMembers)
      .values(member)
      .returning();
    return result[0];
  }

  async deleteClanMember(id: string): Promise<void> {
    await this.db
      .delete(clanMembers)
      .where(eq(clanMembers.id, id));
  }

  async getClanKillRecords(clanId: string): Promise<KillRecord[]> {
    return await this.db
      .select()
      .from(killRecords)
      .where(eq(killRecords.clanId, clanId));
  }

  async saveKillRecord(record: InsertKillRecord): Promise<KillRecord> {
    const result = await this.db
      .insert(killRecords)
      .values(record)
      .returning();
    return result[0];
  }

  async updateKillRecord(id: string, updates: Partial<InsertKillRecord>): Promise<KillRecord | undefined> {
    const result = await this.db
      .update(killRecords)
      .set(updates)
      .where(eq(killRecords.id, id))
      .returning();
    return result[0];
  }

  async saveBossAttendance(attendance: InsertBossAttendance): Promise<BossAttendance> {
    const result = await this.db
      .insert(bossAttendance)
      .values(attendance)
      .returning();
    return result[0];
  }

  async getBossAttendanceByKillRecord(killRecordId: string): Promise<BossAttendance[]> {
    return await this.db
      .select()
      .from(bossAttendance)
      .where(eq(bossAttendance.killRecordId, killRecordId));
  }

  async getClanWeeklyAttendance(clanId: string, weekNumber: number, year: number): Promise<BossAttendance[]> {
    return await this.db
      .select()
      .from(bossAttendance)
      .where(
        and(
          eq(bossAttendance.clanId, clanId),
          eq(bossAttendance.weekNumber, weekNumber),
          eq(bossAttendance.year, year)
        )
      );
  }

  async getMemberWeeklyAttendance(clanId: string, memberName: string, weekNumber: number, year: number): Promise<BossAttendance[]> {
    return await this.db
      .select()
      .from(bossAttendance)
      .where(
        and(
          eq(bossAttendance.clanId, clanId),
          eq(bossAttendance.memberName, memberName),
          eq(bossAttendance.weekNumber, weekNumber),
          eq(bossAttendance.year, year)
        )
      );
  }

  async deleteBossAttendanceByKillRecord(killRecordId: string): Promise<void> {
    await this.db
      .delete(bossAttendance)
      .where(eq(bossAttendance.killRecordId, killRecordId));
  }
}

export const storage = new DrizzleStorage();
