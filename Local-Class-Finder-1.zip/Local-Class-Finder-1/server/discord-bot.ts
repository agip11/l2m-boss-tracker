import { Client, GatewayIntentBits, ChannelType } from "discord.js";

let discordClient: Client | null = null;
let isReady = false;

export async function initializeDiscordBot(token: string) {
  if (!token) {
    console.log("[Discord] Bot token not provided");
    return;
  }

  discordClient = new Client({ intents: [GatewayIntentBits.Guilds] });

  discordClient.once("ready", () => {
    console.log(`[Discord] Bot logged in as ${discordClient?.user?.tag}`);
    isReady = true;
  });

  discordClient.on("error", (error) => {
    console.error("[Discord] Bot error:", error);
  });

  try {
    await discordClient.login(token);
  } catch (error) {
    console.error("[Discord] Failed to login:", error);
    discordClient = null;
  }
}

export function isDiscordBotReady(): boolean {
  return isReady && discordClient !== null && discordClient.isReady();
}

export async function sendWebhookMessage(
  webhookUrl: string,
  message: string,
  embeds?: any[]
): Promise<boolean> {
  if (!webhookUrl) return false;

  try {
    const payload = {
      content: message,
      embeds: embeds || [],
    };
    
    console.log("[Discord] Sending webhook payload:", JSON.stringify(payload, null, 2));
    
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error("[Discord] Webhook error:", response.status, errorText);
    }
    
    return response.ok;
  } catch (error) {
    console.error("[Discord] Failed to send webhook message:", error);
    return false;
  }
}

export function getDiscordInviteUrl(clientId?: string): string {
  if (!clientId) {
    return "https://discord.com/oauth2/authorize?client_id=YOUR_CLIENT_ID&permissions=536870912&scope=bot";
  }
  return `https://discord.com/oauth2/authorize?client_id=${clientId}&permissions=536870912&scope=bot`;
}
