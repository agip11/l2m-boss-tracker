import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { initializeDiscordBot, isDiscordBotReady, sendWebhookMessage } from "./discord-bot";
import { insertDiscordConfigSchema, insertBossStateSchema, insertClanSchema, insertClanMemberSchema, insertKillRecordSchema, insertBossAttendanceSchema } from "@shared/schema";

function getWeekNumber(date: Date): number {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Initialize Discord bot with token from environment
  const discordToken = process.env.DISCORD_BOT_TOKEN;
  if (discordToken) {
    await initializeDiscordBot(discordToken);
  }

  // Discord status endpoint
  app.get("/api/discord/status", (_req, res) => {
    res.json({
      ready: isDiscordBotReady(),
      message: isDiscordBotReady() ? "Discord bot is connected" : "Discord bot is not connected",
    });
  });

  // Get Discord config for a guild
  app.get("/api/discord/config/:guildId", async (req, res) => {
    try {
      const config = await storage.getDiscordConfig(req.params.guildId);
      res.json(config || { guildId: req.params.guildId });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch Discord config" });
    }
  });

  // Save or update Discord config
  app.post("/api/discord/config", async (req, res) => {
    try {
      const validatedData = insertDiscordConfigSchema.parse(req.body);
      
      const existing = await storage.getDiscordConfig(validatedData.guildId);
      let config;
      
      if (existing) {
        config = await storage.updateDiscordConfig(validatedData.guildId, validatedData);
      } else {
        config = await storage.saveDiscordConfig(validatedData);
      }
      
      res.json(config);
    } catch (error) {
      res.status(400).json({ error: "Invalid Discord config data" });
    }
  });

  // Send test notification
  app.post("/api/discord/test-notification", async (req, res) => {
    try {
      const { webhookUrl, message } = req.body;
      
      if (!webhookUrl || !message) {
        return res.status(400).json({ error: "webhookUrl and message are required" });
      }

      const success = await sendWebhookMessage(webhookUrl, message, [{
        title: "Test Notification",
        description: "This is a test message from L2M Tracker",
        color: 16776960, // Yellow
      }]);

      res.json({ success, message: success ? "Message sent successfully" : "Failed to send message" });
    } catch (error) {
      res.status(500).json({ error: "Failed to send test notification" });
    }
  });

  // Report kill and notify Discord
  app.post("/api/kills/report", async (req, res) => {
    try {
      const { bossName, region, killTime, respawnTimeHours, participants, guildId, webhookUrl } = req.body;
      
      // Validation - webhookUrl is optional
      const missingFields = [];
      if (!bossName) missingFields.push("bossName");
      if (!region) missingFields.push("region");
      if (!killTime) missingFields.push("killTime");
      
      if (missingFields.length > 0) {
        return res.status(400).json({ 
          error: "Missing required fields", 
          missing: missingFields,
          received: req.body 
        });
      }
      
      // If no webhookUrl, only save the kill without Discord notification
      if (!webhookUrl || webhookUrl.trim() === "") {
        return res.json({
          success: true,
          message: "Kill recorded (Discord notification not sent - no webhook URL configured)",
        });
      }

      const participantsList = Array.isArray(participants) && participants.length > 0 
        ? participants.join(", ") 
        : "Tidak ada informasi peserta";

      const killDate = new Date(killTime);
      const formattedTime = killDate.toLocaleString("id-ID", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      });

      // Calculate next spawn time
      const nextSpawnDate = new Date(killDate);
      nextSpawnDate.setHours(nextSpawnDate.getHours() + (respawnTimeHours || 0));
      const formattedNextSpawn = nextSpawnDate.toLocaleString("id-ID", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      });

      const message = `⚔️ **${bossName}** berhasil dibunuh!`;
      
      const embed = {
        title: `⚔️ Kill Report - ${bossName}`,
        description: `Boss **${bossName}** di region **${region}** telah berhasil dibunuh`,
        color: 16711680, // Red (in decimal)
        fields: [
          {
            name: "📅 Waktu Kill",
            value: formattedTime,
            inline: false,
          },
          {
            name: "⏰ Respawn",
            value: `${respawnTimeHours} jam`,
            inline: true,
          },
          {
            name: "🔄 Next Spawn",
            value: formattedNextSpawn,
            inline: true,
          },
          {
            name: "🌍 Region",
            value: region,
            inline: false,
          },
          {
            name: "👥 Peserta Kill",
            value: participantsList,
            inline: false,
          },
        ],
        footer: {
          text: "L2M Tracker - Clan Boss Manager",
        },
        timestamp: new Date().toISOString(),
      };

      console.log("[API] Reporting kill:", { bossName, region, respawnTimeHours, formattedTime, formattedNextSpawn });
      
      const success = await sendWebhookMessage(webhookUrl, message, [embed]);
      
      res.json({
        success,
        message: success 
          ? "Kill reported and Discord notified!" 
          : "Kill reported but Discord notification failed",
      });
    } catch (error) {
      console.error("[API] Error reporting kill:", error);
      res.status(500).json({ error: "Failed to report kill" });
    }
  });

  // Reset all boss states to null (untracked)
  app.post("/api/boss-state/reset/all", async (req, res) => {
    try {
      const { bossList } = req.body;
      
      if (!Array.isArray(bossList) || bossList.length === 0) {
        return res.status(400).json({ error: "bossList is required and must be non-empty" });
      }

      let resetCount = 0;
      for (const bossId of bossList) {
        await storage.updateBossState(bossId, { lastKilledTime: null, autoSpawnedAt: null });
        resetCount++;
      }

      res.json({
        success: true,
        message: `Reset ${resetCount} bosses successfully`,
        resetCount,
      });
    } catch (error) {
      console.error("[API] Error resetting boss states:", error);
      res.status(500).json({ error: "Failed to reset boss states" });
    }
  });

  // Get boss state
  app.get("/api/boss-state/:bossId", async (req, res) => {
    try {
      const state = await storage.getBossState(req.params.bossId);
      res.json(state || { bossId: req.params.bossId, lastKilledTime: null, autoSpawnedAt: null });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch boss state" });
    }
  });

  // Save or update boss state
  app.post("/api/boss-state", async (req, res) => {
    try {
      const validatedData = insertBossStateSchema.parse(req.body);
      const state = await storage.saveBossState(validatedData);
      res.json(state);
    } catch (error) {
      res.status(400).json({ error: "Invalid boss state data" });
    }
  });

  // Update boss state
  app.put("/api/boss-state/:bossId", async (req, res) => {
    try {
      const updates = insertBossStateSchema.partial().parse(req.body);
      const state = await storage.updateBossState(req.params.bossId, updates);
      res.json(state);
    } catch (error) {
      res.status(400).json({ error: "Invalid boss state data" });
    }
  });

  // === CLAN API ROUTES ===

  // Get all clans
  app.get("/api/clans", async (_req, res) => {
    try {
      const allClans = await storage.getAllClans();
      res.json(allClans);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch clans" });
    }
  });

  // Get single clan
  app.get("/api/clans/:id", async (req, res) => {
    try {
      const clan = await storage.getClan(req.params.id);
      res.json(clan || null);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch clan" });
    }
  });

  // Create or update clan
  app.post("/api/clans", async (req, res) => {
    try {
      const validatedData = insertClanSchema.parse(req.body);
      const clan = await storage.saveClan(validatedData);
      res.json(clan);
    } catch (error) {
      res.status(400).json({ error: "Invalid clan data" });
    }
  });

  // Update clan
  app.put("/api/clans/:id", async (req, res) => {
    try {
      const updates = insertClanSchema.partial().parse(req.body);
      const clan = await storage.updateClan(req.params.id, updates);
      res.json(clan);
    } catch (error) {
      res.status(400).json({ error: "Invalid clan data" });
    }
  });

  // Get clan members
  app.get("/api/clans/:clanId/members", async (req, res) => {
    try {
      const members = await storage.getClanMembers(req.params.clanId);
      res.json(members);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch clan members" });
    }
  });

  // Add clan member
  app.post("/api/clans/:clanId/members", async (req, res) => {
    try {
      const validatedData = insertClanMemberSchema.parse({
        ...req.body,
        clanId: req.params.clanId
      });
      const member = await storage.saveClanMember(validatedData);
      res.json(member);
    } catch (error) {
      res.status(400).json({ error: "Invalid member data" });
    }
  });

  // Delete clan member
  app.delete("/api/clans/:clanId/members/:memberId", async (req, res) => {
    try {
      await storage.deleteClanMember(req.params.memberId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete member" });
    }
  });

  // Get clan kill records
  app.get("/api/clans/:clanId/kills", async (req, res) => {
    try {
      const records = await storage.getClanKillRecords(req.params.clanId);
      res.json(records);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch kill records" });
    }
  });

  // Add kill record
  app.post("/api/clans/:clanId/kills", async (req, res) => {
    try {
      const validatedData = insertKillRecordSchema.parse({
        ...req.body,
        clanId: req.params.clanId
      });
      const record = await storage.saveKillRecord(validatedData);
      res.json(record);
    } catch (error) {
      res.status(400).json({ error: "Invalid kill record data" });
    }
  });

  // Update kill record (for editing participants)
  app.put("/api/kills/:id", async (req, res) => {
    try {
      const updates = insertKillRecordSchema.partial().parse(req.body);
      const record = await storage.updateKillRecord(req.params.id, updates);
      res.json(record);
    } catch (error) {
      res.status(400).json({ error: "Invalid kill record data" });
    }
  });

  // === ATTENDANCE API ROUTES ===

  // Save attendance for a kill (deduplicated - each member only counted once)
  app.post("/api/clans/:clanId/kills/:killRecordId/attendance", async (req, res) => {
    try {
      const { participants, bossName, killTime, reportedBy } = req.body;
      const clanId = req.params.clanId;
      const killRecordId = req.params.killRecordId;
      
      if (!participants || !Array.isArray(participants)) {
        return res.status(400).json({ error: "participants array is required" });
      }

      const killDate = new Date(killTime);
      const weekNumber = getWeekNumber(killDate);
      const year = killDate.getFullYear();

      // Delete existing attendance for this kill record (in case of update)
      await storage.deleteBossAttendanceByKillRecord(killRecordId);

      // Deduplicate participants - reporter and participants merged, each name only once
      const participantMap: Record<string, string> = {}; // lowercase -> original
      
      for (const p of participants) {
        const trimmed = p.trim();
        if (trimmed) {
          participantMap[trimmed.toLowerCase()] = trimmed;
        }
      }
      
      // Add reporter if not already in participants
      if (reportedBy) {
        const reporterTrimmed = reportedBy.trim();
        if (reporterTrimmed && !participantMap[reporterTrimmed.toLowerCase()]) {
          participantMap[reporterTrimmed.toLowerCase()] = reporterTrimmed;
        }
      }

      const savedAttendance = [];
      for (const memberName of Object.values(participantMap)) {
        const attendance = await storage.saveBossAttendance({
          killRecordId,
          clanId,
          memberName,
          weekNumber,
          year,
          bossName: bossName || "Unknown Boss",
          attendedAt: killTime,
        });
        savedAttendance.push(attendance);
      }

      res.json({ 
        success: true, 
        count: savedAttendance.length,
        attendance: savedAttendance 
      });
    } catch (error) {
      console.error("[API] Error saving attendance:", error);
      res.status(500).json({ error: "Failed to save attendance" });
    }
  });

  // Get weekly attendance recap for a clan
  app.get("/api/clans/:clanId/attendance/weekly", async (req, res) => {
    try {
      const clanId = req.params.clanId;
      const weekParam = req.query.week as string | undefined;
      const yearParam = req.query.year as string | undefined;
      
      const now = new Date();
      const weekNumber = weekParam ? parseInt(weekParam) : getWeekNumber(now);
      const year = yearParam ? parseInt(yearParam) : now.getFullYear();

      const attendance = await storage.getClanWeeklyAttendance(clanId, weekNumber, year);
      
      // Group by member and count points
      const memberPoints: Record<string, { points: number; bosses: string[] }> = {};
      
      for (const record of attendance) {
        if (!memberPoints[record.memberName]) {
          memberPoints[record.memberName] = { points: 0, bosses: [] };
        }
        memberPoints[record.memberName].points += 1;
        memberPoints[record.memberName].bosses.push(record.bossName);
      }

      // Convert to sorted array
      const recap = Object.entries(memberPoints)
        .map(([name, data]) => ({
          memberName: name,
          points: data.points,
          bosses: data.bosses,
        }))
        .sort((a, b) => b.points - a.points);

      res.json({
        clanId,
        weekNumber,
        year,
        totalKills: new Set(attendance.map(a => a.killRecordId)).size,
        recap,
      });
    } catch (error) {
      console.error("[API] Error fetching weekly attendance:", error);
      res.status(500).json({ error: "Failed to fetch weekly attendance" });
    }
  });

  // Get attendance for a specific kill record
  app.get("/api/kills/:killRecordId/attendance", async (req, res) => {
    try {
      const attendance = await storage.getBossAttendanceByKillRecord(req.params.killRecordId);
      res.json(attendance);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch attendance" });
    }
  });

  return httpServer;
}
